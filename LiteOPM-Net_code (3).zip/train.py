"""
Train one model and save predictions on the seen test split and on every
unseen condition.

    python train.py --model liteopm --task both --seed 0
    python train.py --model resnet18 --task both --seed 0

Output: runs/<model>_<task>_s<seed>/{best.pt, history.json, preds.npz, info.json}
"""
import argparse
import json
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

from data import OSNR_MEAN, OSNR_SCALE, load, split
from models import build, count_macs, count_params

HERE = os.path.dirname(os.path.abspath(__file__))


def tensors(d, idx):
    x = torch.from_numpy(d["x"][idx].astype(np.float32) / 255.0).unsqueeze(1)
    f = torch.from_numpy(d["fmt"][idx])
    o = torch.from_numpy((d["osnr"][idx] - OSNR_MEAN) / OSNR_SCALE)
    return x, f, o


DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


@torch.no_grad()
def predict(model, x, bs=256):
    model.eval()
    L, O = [], []
    for i in range(0, len(x), bs):
        l, o = model(x[i:i + bs].to(DEVICE))
        L.append(l.cpu()); O.append(o.cpu())
    logits = torch.cat(L)
    return logits.argmax(1).numpy(), (torch.cat(O) * OSNR_SCALE + OSNR_MEAN).numpy(), \
        torch.softmax(logits, 1).numpy()


def score(task, acc, mae):
    """Lower is better; used for picking the best epoch on validation."""
    if task == "mfi":
        return 1 - acc
    if task == "osnr":
        return mae
    return (1 - acc) + mae / 5.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="liteopm")
    ap.add_argument("--task", default="both", choices=["both", "mfi", "osnr"])
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--lam", type=float, default=1.0, help="OSNR loss weight")
    ap.add_argument("--threads", type=int, default=2)
    a = ap.parse_args()

    torch.manual_seed(a.seed); np.random.seed(a.seed)
    torch.set_num_threads(a.threads)
    out = os.path.join(HERE, "runs", f"{a.model}_{a.task}_s{a.seed}")
    os.makedirs(out, exist_ok=True)

    d = load("seen_*.npz")
    tr, va, te = split(d, seed=0)               # same split for every model
    xtr, ftr, otr = [t.to(DEVICE) for t in tensors(d, tr)]
    print(f"device: {DEVICE}", flush=True)
    xva, fva, ova = tensors(d, va)
    xte, fte, ote = tensors(d, te)

    model = build(a.model, a.task).to(DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=1e-4)
    steps = a.epochs * int(np.ceil(len(tr) / a.bs))
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=a.lr, total_steps=steps,
                                                pct_start=0.15)
    use_cls = a.task in ("both", "mfi")
    use_reg = a.task in ("both", "osnr")

    hist, best, t0 = [], np.inf, time.time()
    for ep in range(a.epochs):
        model.train()
        perm = torch.randperm(len(tr))
        tot = 0.0
        for i in range(0, len(tr), a.bs):
            b = perm[i:i + a.bs].to(DEVICE)
            logits, o = model(xtr[b])
            loss = 0.0
            if use_cls:
                loss = loss + F.cross_entropy(logits, ftr[b])
            if use_reg:
                loss = loss + a.lam * F.l1_loss(o, otr[b])
            opt.zero_grad(); loss.backward(); opt.step(); sched.step()
            tot += loss.item() * len(b)
        pf, po, _ = predict(model, xva)
        acc = float((pf == fva.numpy()).mean())
        mae = float(np.abs(po - d["osnr"][va]).mean())
        s = score(a.task, acc, mae)
        hist.append(dict(epoch=ep + 1, loss=tot / len(tr), val_acc=acc, val_mae=mae,
                         time=time.time() - t0))
        print(f"ep {ep+1:2d} loss {tot/len(tr):.4f} val_acc {acc*100:.2f}% "
              f"val_mae {mae:.3f} dB  [{time.time()-t0:.0f}s]", flush=True)
        if s < best:
            best = s
            torch.save({k: v.detach().cpu() for k, v in model.state_dict().items()},
                       os.path.join(out, "best.pt"))

    model.load_state_dict(torch.load(os.path.join(out, "best.pt"), map_location=DEVICE))
    preds = {}
    pf, po, pp = predict(model, xte)
    preds.update(seen_fmt_pred=pf, seen_osnr_pred=po, seen_prob=pp,
                 seen_fmt=d["fmt"][te], seen_osnr=d["osnr"][te],
                 seen_cond=d["cond"][te], seen_idx=te)
    un = load("unseen_*.npz")
    xu = torch.from_numpy(un["x"].astype(np.float32) / 255.0).unsqueeze(1)
    pf, po, pp = predict(model, xu)
    preds.update(unseen_fmt_pred=pf, unseen_osnr_pred=po, unseen_prob=pp,
                 unseen_fmt=un["fmt"], unseen_osnr=un["osnr"], unseen_cond=un["cond"])
    np.savez_compressed(os.path.join(out, "preds.npz"), **preds)

    train_time = time.time() - t0
    model = model.cpu()                          # MAC counting runs on CPU
    info = dict(model=a.model, task=a.task, seed=a.seed, epochs=a.epochs, lr=a.lr,
                lam=a.lam, bs=a.bs, params=count_params(model),
                macs=count_macs(model), train_time_s=train_time, device=str(DEVICE),
                seen_conditions=d["cond_names"], unseen_conditions=un["cond_names"],
                n_train=len(tr), n_val=len(va), n_test=len(te))
    json.dump(hist, open(os.path.join(out, "history.json"), "w"), indent=1)
    json.dump(info, open(os.path.join(out, "info.json"), "w"), indent=1)
    print(json.dumps(info))


if __name__ == "__main__":
    main()
