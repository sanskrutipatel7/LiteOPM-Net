#!/bin/bash
# Full dataset for the IJMOT study.
# Seen conditions (train / validation / test split later):
#   80, 240, 400 km  x  launch 0 and 2 dBm, 100 kHz linewidth
# Unseen conditions (robustness test only, never used in training):
#   U1: 160 km, 1 dBm            (interpolation in length and power)
#   U2: 560 km, 3 dBm            (extrapolation in length and power)
#   U3:  80 km, 2 dBm, 1 MHz     (unseen, cheaper lasers)
set -e
cd "$(dirname "$0")"
mkdir -p data
PC=10   # images per (format, OSNR) per condition -> 1260 per condition

run () {
  if [ -f data/$1.npz ]; then echo "skip $1 (done)"; return; fi
  echo "$(date +%T) start $1"
  python3 make_dataset.py "${@:2}" --per_class $PC --out data/$1.tmp.npz && mv data/$1.tmp.npz data/$1.npz
}

run seen_80km_0dBm   --spans 1 --launch_dbm 0 --seed 1000
run seen_80km_2dBm   --spans 1 --launch_dbm 2 --seed 2000
run seen_240km_0dBm  --spans 3 --launch_dbm 0 --seed 3000
run seen_240km_2dBm  --spans 3 --launch_dbm 2 --seed 4000
run seen_400km_0dBm  --spans 5 --launch_dbm 0 --seed 5000
run seen_400km_2dBm  --spans 5 --launch_dbm 2 --seed 6000
run unseen_160km_1dBm --spans 2 --launch_dbm 1 --seed 7000
run unseen_560km_3dBm --spans 7 --launch_dbm 3 --seed 8000
run unseen_80km_2dBm_1MHz --spans 1 --launch_dbm 2 --linewidth_khz 1000 --seed 9000
echo "$(date +%T) ALL DONE"
