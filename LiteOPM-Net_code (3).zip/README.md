# LiteOPM-Net: code and data for the IJMOT manuscript

Reproduces every number, table and figure in the paper.
Needs Python 3.10+, numpy, scipy, matplotlib, scikit-learn, PyTorch, torchvision.
Node.js with the `docx` package is needed only to rebuild the Word file.

## Easiest: Google Colab

Open `LiteOPM-Net_rerun_colab.ipynb` in Google Colab, choose a T4 GPU runtime, click
**Runtime > Run all** and upload the zip files when asked. The last cells compare your
numbers with the manuscript.

## Steps (any computer)

| Step | Command | Output | Time (2-core CPU) |
|---|---|---|---|
| 1. Check the simulator | `python validate_sim.py` | `validation.json` | ~3 min |
| 2. Generate the dataset | `./run_full_dataset.sh` | `data/*.npz` (9 conditions, 11,340 images) | ~45 min |
| 3. Train all models, 3 seeds | `./run_training.sh` | `runs/<model>_<task>_s<seed>/` | ~2.5 h |
| 4. Grad-CAM analysis | `python xai.py --run runs/liteopm_both_s0` | `xai.json`, `cams.npz` | ~1 min |
| 5. Tables and figures | `python analyze.py`, `python fig_schematics.py`, `python fig_gradcam.py` | `results.json`, `figs/` | ~2 min |
| 6. Build the manuscript | `cd paper && node build_paper.js && python merge_into_template.py template/IJMOT_Manuscript_Template.dotx body_IJMOT_LiteOPM-Net_manuscript.docx IJMOT_LiteOPM-Net_manuscript.docx` | `.docx` in the IJMOT template | seconds |

On a GPU, step 3 takes about 30-60 minutes. Training uses the GPU automatically if one is present.
Exact numbers depend on hardware and thread count (rounding order); the paper's runs used one CPU thread
(`--threads 1`), which reproduces them bit for bit. On other hardware, expect agreement within the seed spread.

## Files

- `fibre_sim.py` - coherent link simulator (split-step fibre model, EDFA, ASE noise loading, receiver DSP)
- `make_dataset.py` - constellation image generator for one link condition
- `data.py`, `models.py`, `train.py` - data split, models (LiteOPM-Net and baselines), training
- `xai.py` - Grad-CAM, region analysis and deletion test
- `analyze.py` - aggregates runs into `results.json` and Figs. 4 and 6
- `paper/content.js`, `paper/content_results.js` - manuscript text; all result numbers are read from the JSON files
- `simulate_pilot.py`, `check_pilot.py` - earlier simple pilot (not used in the paper)

## Notes

- Seeds are fixed, so results should match closely; small differences in CPU latency are normal.
- The train/validation/test split is identical for every model and seed (`data.split`, seed 0).
