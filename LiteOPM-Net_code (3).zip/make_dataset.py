"""
Generate an MFI / OSNR dataset of constellation images with fibre_sim.py.

Pilot:   python make_dataset.py --spans 1 --per_class 30 --out pilot_ssfm.npz
Full set (later): loop over --spans 1 2 5 10 and --launch_dbm -2 0 2 4
                  and concatenate, keeping some settings unseen for testing.
"""
import argparse
import json
import os
from multiprocessing import Pool

import numpy as np
from fibre_sim import FORMATS, Link

N_SYM = 4096            # data symbols per image
IMG = 64
AXIS = 1.9              # plot range (+/-) on unit-power scale
OSNR_DB = np.arange(10, 31, 1)


def to_image(y):
    h, _, _ = np.histogram2d(y.real, y.imag, bins=IMG,
                             range=[[-AXIS, AXIS], [-AXIS, AXIS]])
    h = np.log1p(h)
    h = h / h.max() if h.max() > 0 else h
    return (h.T[::-1] * 255).astype(np.uint8)


def job(args):
    fi, osnr, seed, link_kw = args
    rng = np.random.default_rng(seed)
    r, _, snr = Link(**link_kw).run(FORMATS[fi], osnr, N_SYM, rng)
    return to_image(r), fi, osnr, snr


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--spans", type=int, default=1, help="80 km spans")
    ap.add_argument("--launch_dbm", type=float, default=2.0)
    ap.add_argument("--linewidth_khz", type=float, default=100.0)
    ap.add_argument("--per_class", type=int, default=30)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--workers", type=int, default=os.cpu_count())
    ap.add_argument("--out", default="pilot_ssfm.npz")
    a = ap.parse_args()

    link_kw = dict(n_spans=a.spans, launch_dbm=a.launch_dbm,
                   linewidth_hz=a.linewidth_khz * 1e3)
    jobs, s = [], a.seed
    for fi in range(len(FORMATS)):
        for o in OSNR_DB:
            for _ in range(a.per_class):
                jobs.append((fi, float(o), s, link_kw)); s += 1

    with Pool(a.workers) as p:
        res = p.map(job, jobs, chunksize=8)

    img, fmt, osnr, snr = zip(*res)
    lk = Link(**link_kw)
    meta = dict(formats=FORMATS, osnr_db=OSNR_DB.tolist(),
                fibre_km=lk.length_km, launch_dbm=a.launch_dbm,
                linewidth_hz=lk.linewidth, baud=lk.baud,
                pilot_every=lk.pilot_every, cpe_window=lk.cpe_window,
                n_sym_per_image=N_SYM, image_size=IMG, axis_range=AXIS,
                per_class=a.per_class, seed=a.seed,
                model="scalar NLSE split-step, EDFA spans, ASE noise loading, "
                      "ideal CD comp, RRC matched filter, pilot-aided CPE")
    np.savez_compressed(a.out, images=np.stack(img),
                        fmt=np.array(fmt, np.int8),
                        osnr=np.array(osnr, np.float32),
                        snr_eff=np.array(snr, np.float32),
                        meta=json.dumps(meta))
    print(f"Saved {len(img)} images ({lk.length_km:.0f} km, "
          f"{a.launch_dbm} dBm) to {a.out}")


if __name__ == "__main__":
    main()
