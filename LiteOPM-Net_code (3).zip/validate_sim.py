"""
Physics checks for fibre_sim.py, saved to validation.json. Each test compares
the simulator with a result known from theory.

  1. Back-to-back: measured SNR must match SNR = OSNR + 10log10(Bref/Rs)
  2. Linear fibre (gamma = 0): after CD compensation the signal must be
     recovered to the noise-only limit, for 80 km and 800 km
  3. Nonlinear fibre, no ASE: nonlinear SNR must fall ~2 dB per 1 dB
     increase in launch power (GN-model behaviour)
  4. SSFM step size: result must not depend on step (0.5, 1, 2 km)
"""
import json
import numpy as np
from fibre_sim import Link, osnr_to_snr_db

rng = np.random.default_rng(1)
N = 8192
out = {}

print("1) Back-to-back noise loading (16QAM, no fibre, no phase noise)")
b2b = []
for o in [10, 15, 20, 25, 30]:
    _, _, snr = Link(n_spans=0, linewidth_hz=0).run("16QAM", o, N, rng)
    b2b.append(dict(osnr=o, theory=osnr_to_snr_db(o), measured=snr))
    print(f"   OSNR {o:2d} dB -> theory {osnr_to_snr_db(o):5.2f}, measured {snr:5.2f} dB")
out["b2b"] = b2b
out["b2b_max_err"] = max(abs(r["theory"] - r["measured"]) for r in b2b)

print("2) Linear fibre, CD compensation (64QAM, gamma=0, OSNR 60 dB)")
lin = []
for spans in [1, 10]:
    _, _, snr = Link(n_spans=spans, gamma=0.0, linewidth_hz=0).run("64QAM", 60, N, rng)
    lin.append(dict(km=spans * 80, snr=snr, limit=osnr_to_snr_db(60)))
    print(f"   {spans*80:4d} km -> SNR {snr:5.1f} dB (limit {osnr_to_snr_db(60):.1f})")
out["linear"] = lin

print("3) Nonlinear penalty vs launch power (16QAM, 800 km, OSNR 60 dB)")
nl = []
for p in [0, 2, 4, 6, 8]:
    _, _, snr = Link(n_spans=10, launch_dbm=p, linewidth_hz=0).run("16QAM", 60, N, rng)
    nl.append(dict(launch_dbm=p, snr=snr))
    print(f"   launch {p:+d} dBm -> SNR {snr:5.1f} dB")
out["nonlinear"] = nl
slopes = [(nl[i + 1]["snr"] - nl[i]["snr"]) / 2 for i in range(len(nl) - 1)]
out["nl_slope_db_per_db"] = [min(slopes), max(slopes)]

print("4) SSFM step size (16QAM, 800 km, 4 dBm)")
st = []
for step in [0.5, 1.0, 2.0]:
    r = np.random.default_rng(5)
    _, _, snr = Link(n_spans=10, launch_dbm=4, step_km=step, linewidth_hz=0).run("16QAM", 60, N, r)
    st.append(dict(step_km=step, snr=snr))
    print(f"   step {step} km -> SNR {snr:.3f} dB")
out["step"] = st
out["step_spread_db"] = max(s["snr"] for s in st) - min(s["snr"] for s in st)

json.dump(out, open("validation.json", "w"), indent=1)
print(json.dumps({k: out[k] for k in ("b2b_max_err", "nl_slope_db_per_db", "step_spread_db")}))
