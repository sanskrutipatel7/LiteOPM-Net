"""
fibre_sim.py - a small, self-contained coherent optical link simulator
(numpy only) for generating MFI / OSNR-monitoring datasets.

Signal chain
------------
Tx   : random symbols (6 formats) + periodic QPSK pilots
       -> root-raised-cosine (RRC) pulse shaping, 4 samples/symbol
       -> laser phase noise (Wiener process, combined Tx+LO linewidth)
Fibre: N spans of SSMF, each solved with the symmetric split-step Fourier
       method on the scalar nonlinear Schrodinger equation (loss,
       chromatic dispersion, Kerr nonlinearity), followed by an EDFA that
       restores the span loss
Rx   : ASE noise loading to set the OSNR exactly (0.1 nm reference)
       -> ideal chromatic-dispersion compensation (frequency domain)
       -> RRC matched filter, downsample to 1 sample/symbol
       -> pilot-aided carrier phase recovery (format-agnostic)
       -> AGC, drop pilots and edge symbols

Simplifications (state these in the paper):
  - single polarisation (scalar NLSE), single channel (no WDM / XPM)
  - ASE added once at the receiver (noise loading) rather than per span
  - ideal timing recovery

Units: time in s, length in km, power in W.
"""

import numpy as np
from scipy.fft import next_fast_len

C =299792458.0             # speed of light (m/s)
LAMBDA = 1550e-9            # carrier wavelength (m)
B_REF = 12.5e9              # OSNR reference bandwidth, 0.1 nm (Hz)

FORMATS = ["QPSK", "8PSK", "8QAM", "16QAM", "32QAM", "64QAM"]


# ================================================================ formats
def _square_qam(m):
    k = int(np.sqrt(m))
    lv = np.arange(-(k - 1), k, 2)
    i, q = np.meshgrid(lv, lv)
    return (i + 1j * q).ravel()


def constellation(name):
    if name == "QPSK":
        c = np.exp(1j * (np.pi / 4 + np.pi / 2 * np.arange(4)))
    elif name == "8PSK":
        c = np.exp(1j * np.pi / 4 * np.arange(8))
    elif name == "8QAM":                        # star 8QAM, ring ratio 1+sqrt(3)
        c = np.concatenate([
            np.exp(1j * np.pi / 2 * np.arange(4)),
            (1 + np.sqrt(3)) * np.exp(1j * (np.pi / 4 + np.pi / 2 * np.arange(4))),
        ])
    elif name == "16QAM":
        c = _square_qam(16)
    elif name == "32QAM":                       # cross 32QAM
        lv = np.arange(-5, 6, 2)
        i, q = np.meshgrid(lv, lv)
        p = (i + 1j * q).ravel()
        c = p[~((np.abs(p.real) == 5) & (np.abs(p.imag) == 5))]
    elif name == "64QAM":
        c = _square_qam(64)
    else:
        raise ValueError(name)
    return c / np.sqrt(np.mean(np.abs(c) ** 2))


# ================================================================ filters
def rrc_freq(n, fs, baud, rolloff):
    """Frequency response of a root-raised-cosine filter (zero phase)."""
    f = np.abs(np.fft.fftfreq(n, 1 / fs))
    f1 = (1 - rolloff) * baud / 2
    f2 = (1 + rolloff) * baud / 2
    h = np.zeros(n)
    h[f <= f1] = 1.0
    mid = (f > f1) & (f <= f2)
    h[mid] = np.sqrt(0.5 * (1 + np.cos(np.pi / (rolloff * baud) * (f[mid] - f1))))
    return h


# ================================================================ link
class Link:
    def __init__(self, baud=32e9, sps=4, rolloff=0.1,
                 n_spans=1, span_km=80.0, alpha_db=0.2, d_ps_nm_km=17.0,
                 gamma=1.3, launch_dbm=2.0, step_km=1.0,
                 linewidth_hz=100e3, pilot_every=32, cpe_window=9):
        self.baud, self.sps, self.rolloff = baud, sps, rolloff
        self.fs = baud * sps
        self.n_spans, self.span_km = n_spans, span_km
        self.alpha = alpha_db / (10 * np.log10(np.e))           # 1/km (power)
        d = d_ps_nm_km * 1e-12 / (1e-9 * 1e3)                    # s/m^2
        self.beta2 = -d * LAMBDA ** 2 / (2 * np.pi * C) * 1e3   # s^2/km
        self.gamma = gamma                                       # 1/W/km
        self.p_launch = 1e-3 * 10 ** (launch_dbm / 10)          # W
        self.step_km = step_km
        self.linewidth = linewidth_hz
        self.pilot_every = pilot_every
        self.cpe_window = cpe_window

    @property
    def length_km(self):
        return self.n_spans * self.span_km

    # ---------------------------------------------------------- transmitter
    def transmit(self, fmt, n_data, rng):
        """Return the Tx field, the full symbol sequence and a data mask."""
        n_sym = n_data
        while n_sym - (-(-n_sym // self.pilot_every)) < n_data:
            n_sym += 1                                  # make room for pilots
        n_sym = next_fast_len(n_sym)                   # fast FFT length
        is_pilot = np.zeros(n_sym, bool)
        is_pilot[:: self.pilot_every] = True
        c_data = constellation(fmt)
        c_pil = constellation("QPSK")
        sym = np.empty(n_sym, complex)
        sym[is_pilot] = c_pil[rng.integers(0, 4, is_pilot.sum())]
        sym[~is_pilot] = c_data[rng.integers(0, len(c_data), (~is_pilot).sum())]

        up = np.zeros(n_sym * self.sps, complex)
        up[:: self.sps] = sym
        n = up.size
        x = np.fft.ifft(np.fft.fft(up) * rrc_freq(n, self.fs, self.baud, self.rolloff))
        x *= np.sqrt(self.p_launch / np.mean(np.abs(x) ** 2))

        if self.linewidth > 0:
            var = 2 * np.pi * self.linewidth / self.fs
            x *= np.exp(1j * np.cumsum(rng.normal(0, np.sqrt(var), n)))
        return x, sym, is_pilot

    # ---------------------------------------------------------- fibre
    def propagate(self, x):
        n = x.size
        w = 2 * np.pi * np.fft.fftfreq(n, 1 / self.fs)
        n_steps = int(round(self.span_km / self.step_km))
        dz = self.span_km / n_steps
        half_lin = np.exp((-self.alpha / 2 + 0.5j * self.beta2 * w ** 2) * dz / 2)
        for _ in range(self.n_spans):
            for _ in range(n_steps):                    # symmetric split-step
                x = np.fft.ifft(np.fft.fft(x) * half_lin)
                x = x * np.exp(1j * self.gamma * np.abs(x) ** 2 * dz)
                x = np.fft.ifft(np.fft.fft(x) * half_lin)
            x = x * np.exp(self.alpha * self.span_km / 2)  # EDFA: restore loss
        return x

    # ---------------------------------------------------------- receiver
    def add_ase(self, x, osnr_db, rng):
        """Noise loading. Scalar field = one polarisation of a DP signal,
        so OSNR = P_pol / (N0 * B_ref) with N0 the ASE PSD per polarisation."""
        p = np.mean(np.abs(x) ** 2)
        n0 = p / (10 ** (osnr_db / 10) * B_REF)
        sigma = np.sqrt(n0 * self.fs / 2)
        return x + sigma * (rng.normal(size=x.size) + 1j * rng.normal(size=x.size))

    def receive(self, y, sym, is_pilot):
        n = y.size
        w = 2 * np.pi * np.fft.fftfreq(n, 1 / self.fs)
        cd_comp = np.exp(-0.5j * self.beta2 * w ** 2 * self.length_km)
        y = np.fft.ifft(np.fft.fft(y) * cd_comp
                        * rrc_freq(n, self.fs, self.baud, self.rolloff))
        r = y[:: self.sps]
        r = r / np.sqrt(np.mean(np.abs(r) ** 2))

        # pilot-aided carrier phase recovery (does not need the data format)
        idx = np.flatnonzero(is_pilot)
        z = r[idx] * np.conj(sym[idx])
        k = np.ones(self.cpe_window) / self.cpe_window
        z_pad = np.concatenate([z[-self.cpe_window:], z, z[: self.cpe_window]])
        z_s = np.convolve(z_pad, k, mode="same")[self.cpe_window:-self.cpe_window]
        ph = np.unwrap(np.angle(z_s))
        phase = np.interp(np.arange(r.size), idx, ph)
        r = r * np.exp(-1j * phase)

        d = r[~is_pilot]
        return d / np.sqrt(np.mean(np.abs(d) ** 2)), sym[~is_pilot]

    # ---------------------------------------------------------- full chain
    def run(self, fmt, osnr_db, n_data, rng, edge=64):
        """Returns recovered data symbols, transmitted data symbols and
        the effective SNR (dB) measured from EVM."""
        x, sym, is_pilot = self.transmit(fmt, n_data + 2 * edge, rng)
        y = self.add_ase(self.propagate(x), osnr_db, rng)
        r, s = self.receive(y, sym, is_pilot)
        r, s = r[edge:edge + n_data], s[edge:edge + n_data]
        # best complex scaling, then EVM -> effective SNR
        g = np.vdot(s, r) / np.vdot(s, s)
        err = r / g - s
        snr_eff = 10 * np.log10(np.mean(np.abs(s) ** 2) / np.mean(np.abs(err) ** 2))
        return r, s, snr_eff


def osnr_to_snr_db(osnr_db, baud=32e9):
    """Theoretical SNR per symbol after matched filtering (ASE only)."""
    return osnr_db + 10 * np.log10(B_REF / baud)
