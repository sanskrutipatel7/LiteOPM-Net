// Results, discussion, conclusion and abstract. All numbers come from JSON.
const NAMES = { liteopm: "LiteOPM-Net (ours)", alexstyle: "AlexNet-style CNN",
  mobilenetv2: "MobileNetV2", resnet18: "ResNet-18" };
const ORDER = ["liteopm", "alexstyle", "mobilenetv2", "resnet18"];
const THE = (m) => (m === "alexstyle" ? "the " : "") + NAMES[m];
const UN = ["unseen_160km_1dBm", "unseen_560km_3dBm", "unseen_80km_2dBm_1MHz"];
const UNL = { unseen_160km_1dBm: "160 km, 1 dBm", unseen_560km_3dBm: "560 km, 3 dBm",
  unseen_80km_2dBm_1MHz: "80 km, 1 MHz" };

function validationText(V) {
  const lin = V.linear;
  return `The simulator was checked against four known results before data generation. With no fibre, the measured SNR after matched filtering followed (2) to within ${V.b2b_max_err.toFixed(2)} dB over 10–30 dB OSNR; the small constant shortfall is the expected penalty of pilot-based phase estimation. With the nonlinearity switched off, 64QAM was recovered after ${lin[0].km} km and ${lin[1].km} km at ${lin[0].snr.toFixed(1)} dB SNR against a noise-only limit of ${lin[0].limit.toFixed(1)} dB, confirming that dispersion is fully compensated. With the nonlinearity on and no ASE, the SNR after 800 km fell by ${(-V.nl_slope_db_per_db[1]).toFixed(1)}–${(-V.nl_slope_db_per_db[0]).toFixed(1)} dB per 1 dB of extra launch power, close to the 2:1 slope predicted by the Gaussian-noise model [14]. Finally, results changed by only ${V.step_spread_db.toFixed(3)} dB when the SSFM step was varied from 0.5 to 2 km.`;
}

function abstract(R, X) {
  const L = R.models.liteopm;
  const base = ORDER.slice(1).filter((m) => R.models[m]);
  const ratio = Math.round(Math.max(L.params, ...base.map((m) => R.models[m].params)) / L.params);
  return `Monitors in elastic optical networks must identify the modulation format and estimate the optical signal-to-noise ratio (OSNR). We propose LiteOPM-Net, a lightweight multi-task convolutional neural network that does both from one constellation image. On coherent links simulated with the split-step Fourier method, it reaches ${(100 * L.acc[0]).toFixed(1)}% accuracy over six formats and ${L.mae[0].toFixed(2)} dB OSNR error with ${(L.params / 1e3).toFixed(0)} k parameters, close to baselines up to ${ratio} times larger. Grad-CAM maps, checked by a deletion test and a physics-based region analysis, show that it reads the format from cluster positions and OSNR from noise spread. Tests on unseen links show where fibre nonlinearity limits OSNR monitoring.`;
}

function bestBaseline(R) {
  return ORDER.slice(1).filter((m) => R.models[m])
    .sort((a, b) => R.models[b].acc[0] - R.models[a].acc[0])[0] ?? "liteopm";
}

function results(R, X, pm, pct, f1, f2, kfmt) {
  const L = R.models.liteopm;
  const A = R.ablation;
  const avail = ORDER.filter((m) => R.models[m]);
  const base = avail.slice(1);
  const best = bestBaseline(R);
  const B = R.models[best];
  const lowestMae = avail.slice().sort((a, b) => R.models[a].mae[0] - R.models[b].mae[0])[0];
  const pf = R.per_format;
  const ub = R.unseen_bias;
  const dauc = R.deletion_auc;
  const phys = X.physics.all;
  const enr = (k, i) => (phys[k][i] / phys.area[i]).toFixed(2);
  const singleParams = A.mfi.params + A.osnr.params;
  const singleMacs = A.mfi.macs + A.osnr.macs;
  const accGap = 100 * (B.acc[0] - L.acc[0]);
  const lat = (m) => R.models[m].latency_ms;
  const fastestBase = base.slice().sort((a, b) => lat(a) - lat(b))[0] ?? "liteopm";
  const rank = (key, low) => 1 + avail.filter((m) => m !== "liteopm" &&
    (low ? R.models[m][key][0] < L[key][0] : R.models[m][key][0] > L[key][0])).length;
  const ordinal = (n) => ["first", "second", "third", "fourth"][n - 1];
  const rA = rank("acc", false), rE = rank("mae", true);
  const rankText = rA === rE ? `Among the four models, LiteOPM-Net ranks ${ordinal(rA)} in both format accuracy and OSNR error.`
    : `Among the four models, LiteOPM-Net ranks ${ordinal(rA)} in format accuracy and ${ordinal(rE)} in OSNR error.`;
  const u560all = avail.map((m) => R.unseen[m].unseen_560km_3dBm.mae[0]);
  // is the gap to the best baseline larger than the seed spread?
  const E = R.models[lowestMae];
  const accGapSd = Math.max(L.acc[1], B.acc[1]);
  const maeGap = L.mae[0] - E.mae[0], maeGapSd = Math.max(L.mae[1], E.mae[1]);
  const accPart = accGap <= 0.05 ? "" : (100 * accGapSd >= accGap
    ? `The ${accGap.toFixed(1)}-point accuracy gap to ${THE(best)} is smaller than the seed-to-seed spread.`
    : `The ${accGap.toFixed(1)}-point accuracy gap to ${THE(best)} is larger than the seed-to-seed spread.`);
  const maePart = lowestMae === "liteopm" ? "" : (maeGapSd >= maeGap
    ? ` The ${maeGap.toFixed(2)} dB OSNR gap to ${THE(lowestMae)} is within the seed spread.`
    : ` ${THE(lowestMae)}'s ${maeGap.toFixed(2)} dB lower OSNR error is larger than the seed spread and is likely a real, if small, advantage of the much larger model.`);
  const spreadText = (accPart + maePart).trim() + " The main gain of LiteOPM-Net is therefore in size and speed, at similar accuracy.";

  // bold the best value in each column (ties at the shown precision all bold)
  const bestOf = (vals, lowIsBest, dp) => {
    const r = vals.map((v) => Number(v.toFixed(dp)));
    const b = lowIsBest ? Math.min(...r) : Math.max(...r);
    return r.map((v) => v === b);
  };
  const col = (f) => avail.map((m) => f(R.models[m]));
  const bP = bestOf(col((e) => e.params), true, 0), bM = bestOf(col((e) => e.macs / 1e6), true, 1),
    bL = bestOf(col((e) => e.latency_ms), true, 2), bA = bestOf(col((e) => 100 * e.acc[0]), false, 1),
    bAL = bestOf(col((e) => 100 * e.acc_low[0]), false, 1), bE = bestOf(col((e) => e.mae[0]), true, 2),
    bR = bestOf(col((e) => e.rmse[0]), true, 2);
  const modelRows = avail.map((m, i) => {
    const e = R.models[m];
    return { cells: [NAMES[m], kfmt(e.params), (e.macs / 1e6).toFixed(1), e.latency_ms.toFixed(2),
      pm(e.acc, 1, 100), pm(e.acc_low, 1, 100), pm(e.mae, 2), pm(e.rmse, 2)],
      bold: [false, bP[i], bM[i], bL[i], bA[i], bAL[i], bE[i], bR[i]] };
  });

  const ub_ = UN.flatMap((c) => [bestOf(avail.map((m) => 100 * R.unseen[m][c].acc[0]), false, 1),
    bestOf(avail.map((m) => R.unseen[m][c].mae[0]), true, 2)]);
  const unRows = avail.map((m, i) => ({ cells: [NAMES[m],
    ...UN.flatMap((c) => [pm(R.unseen[m][c].acc, 1, 100), pm(R.unseen[m][c].mae, 2)])],
    bold: [false, ...ub_.map((b) => b[i])] }));

  const u560 = ub.unseen_560km_3dBm, u1m = ub.unseen_80km_2dBm_1MHz, u160 = ub.unseen_160km_1dBm;
  const snr30 = R.snr_at_30dB;
  const minSeenSnr30 = Math.min(...Object.entries(snr30).filter(([k]) => k.startsWith("seen")).map(([, v]) => v));

  return [
    { t: "h1", text: "V. Results and Discussion" },
    { t: "h2", text: "A. Accuracy and efficiency" },
    { t: "p", text: `Table 3 compares the four models on the seen test set, which holds the same 1,512 images for every model and seed. LiteOPM-Net reaches ${pm(L.acc, 1, 100)}% format accuracy and an OSNR MAE of ${pm(L.mae, 2)} dB. ${accGap > 0.05 ? `The most accurate baseline, ${THE(best)}, is ${accGap.toFixed(1)} percentage points higher in accuracy` : `No baseline is more accurate`}, while LiteOPM-Net uses ${Math.round(B.params / L.params)} times fewer parameters and ${Math.round(B.macs / L.macs)} times fewer MACs than it. ${lowestMae === "liteopm" ? "LiteOPM-Net also has the lowest OSNR error of all models." : `The lowest OSNR error is obtained by ${THE(lowestMae)} (${R.models[lowestMae].mae[0].toFixed(2)} dB).`} ${rankText} On one CPU thread LiteOPM-Net needs ${L.latency_ms.toFixed(2)} ms per image, against ${lat(fastestBase).toFixed(2)} ms for the fastest baseline (${THE(fastestBase)}). ${spreadText}` },
    { t: "table", wide: true, caption: "Table 3: Performance on the seen test set (mean ± std over three seeds)",
      fr: [1.7, 0.8, 0.8, 0.9, 1.1, 1.2, 1.1, 1.1],
      header: ["Model", "Params", "MACs (M)", "CPU ms/img", "MFI acc. (%)", "MFI acc. 10–14 dB (%)", "OSNR MAE (dB)", "OSNR RMSE (dB)"],
      rows: modelRows, note: "Latency: one CPU thread, batch size 1, mean of 300 runs." },
    { t: "fig", file: "fig4_results.png", w: 6.6, wide: true, caption: "Fig. 4. (a) MFI accuracy versus OSNR for all models; (b) confusion matrix of LiteOPM-Net for OSNR 10–14 dB; (c) estimated versus true OSNR for LiteOPM-Net (seed 0, small horizontal jitter for visibility)." },
    { t: "cols", n: 2 },
    { t: "p", text: `Fig. 4(a) shows that every model is error-free at high OSNR and that all errors occur at low OSNR. LiteOPM-Net identifies every test image correctly from ${R.first_osnr_100.liteopm} dB OSNR upward. Its accuracy is ${pct(pf.QPSK.acc)}%, ${pct(pf["8PSK"].acc)}%, ${pct(pf["8QAM"].acc)}% and ${pct(pf["32QAM"].acc)}% for QPSK, 8PSK, 8QAM and 32QAM, but ${pct(pf["16QAM"].acc)}% for 16QAM and ${pct(pf["64QAM"].acc)}% for 64QAM. Fig. 4(b) shows why: at 10–14 dB OSNR almost all errors are confusions between 16QAM and 64QAM. At these noise levels both constellations blur into a uniformly filled square (Fig. 2), so the image itself holds little information to separate them. 32QAM stays distinguishable because its cross shape leaves the corners empty. Fig. 4(c) shows that OSNR estimates follow the true value closely, with a wider spread above about 25 dB where the 400 km, 2 dBm link is limited by nonlinear noise rather than ASE.` },

    { t: "h2", text: "B. Multi-task versus single-task learning" },
    { t: "p", text: `Table 4 compares the joint model with two single-task copies of the same network. The joint model reaches ${pm(A.both.acc, 1, 100)}% accuracy against ${pm(A.mfi.acc, 1, 100)}% for the MFI-only model, and ${pm(A.both.mae, 2)} dB OSNR MAE against ${pm(A.osnr.mae, 2)} dB for the OSNR-only model. ${Math.abs(A.both.acc[0] - A.mfi.acc[0]) < A.mfi.acc[1] + A.both.acc[1] ? "The accuracy difference is within the seed-to-seed spread" : "The accuracy difference exceeds the seed spread"}, and ${A.both.mae[0] <= A.osnr.mae[0] ? "OSNR error is slightly lower with joint training" : "OSNR error is slightly higher with joint training"}. Sharing the backbone therefore costs nothing in accuracy while needing ${(100 * (1 - A.both.params / singleParams)).toFixed(0)}% fewer parameters and ${(100 * (1 - A.both.macs / singleMacs)).toFixed(0)}% fewer MACs than running the two single-task models side by side.` },
    { t: "table", caption: "Table 4: Joint versus single-task LiteOPM-Net", fr: [1.5, 0.9, 1.2, 1.2],
      header: ["Model", "Params", "MFI acc. (%)", "OSNR MAE (dB)"],
      rows: [
        { cells: ["Joint (ours)", kfmt(A.both.params), pm(A.both.acc, 1, 100), pm(A.both.mae, 2)], bold: [true] },
        ["MFI only", kfmt(A.mfi.params), pm(A.mfi.acc, 1, 100), "–"],
        ["OSNR only", kfmt(A.osnr.params), "–", pm(A.osnr.mae, 2)],
        ["Two single-task", kfmt(singleParams), pm(A.mfi.acc, 1, 100), pm(A.osnr.mae, 2)],
      ] },

    { t: "h2", text: "C. What the network looks at" },
    { t: "p", text: "Fig. 5 shows Grad-CAM maps for three test images. For the MFI head the maps cover the constellation clusters and their arrangement. For the OSNR head, evidence that raises the estimate lies mostly in the empty space between and around clusters, while evidence that lowers it sits at the fuzzy edges of clusters where noisy symbols spill out." },
    { t: "fig", file: "fig5_gradcam.png", w: 3.05, caption: "Fig. 5. Grad-CAM maps of LiteOPM-Net. Red marks the regions that most support the output named at the top of each column." },
    { t: "p", text: `Table 5 puts numbers on this across ${X.n_images} test images. A value above 1 means a map places more of its weight in a region than the region's share of the image. The MFI map is concentrated on the cluster cores (${enr("mfi", 0)}) and halos (${enr("mfi", 1)}) and avoids the gaps (${enr("mfi", 2)}), as expected for a task about where clusters are. Evidence that lowers the OSNR estimate is most concentrated in the halo (${enr("lo", 1)}), the region filled by noise. Evidence that raises it is spread over the gaps (${enr("hi", 2)}) and avoids the halo (${enr("hi", 1)}): the network judges high OSNR by how empty the space around the clusters is. Both patterns match how an engineer reads a constellation.` },
    { t: "table", caption: "Table 5: Grad-CAM weight relative to region area (>1: concentrated)", fr: [1.7, 0.8, 0.8, 0.8],
      header: ["Map", "Core", "Halo", "Gaps"],
      rows: [
        ["Region share of area", (phys.area[0] * 100).toFixed(0) + "%", (phys.area[1] * 100).toFixed(0) + "%", (phys.area[2] * 100).toFixed(0) + "%"],
        ["MFI head", enr("mfi", 0), enr("mfi", 1), enr("mfi", 2)],
        ["OSNR: raises estimate", enr("hi", 0), enr("hi", 1), enr("hi", 2)],
        ["OSNR: lowers estimate", enr("lo", 0), enr("lo", 1), enr("lo", 2)],
      ] },
    { t: "p", text: `The deletion test in Fig. 6(a)–(b) confirms that these maps are faithful. Removing pixels in Grad-CAM order lowers MFI accuracy much faster than random removal; averaged over 0–50% deletion, accuracy is ${pct(dauc.mfi_acc.gradcam)}% against ${pct(dauc.mfi_acc.random)}% for random order. For the OSNR head, the average error rises to ${dauc.osnr_mae.gradcam.toFixed(2)} dB against ${dauc.osnr_mae.random.toFixed(2)} dB. The highlighted pixels are therefore the ones the predictions actually depend on.` },
    { t: "fig", file: "fig6_faithful_robust.png", w: 6.6, wide: true, caption: "Fig. 6. (a)–(b) Deletion test for LiteOPM-Net: pixels removed in Grad-CAM order versus random order. (c) OSNR MAE on the three unseen link conditions for all models (mean ± std over three seeds)." },
    { t: "cols", n: 2 },

    { t: "h2", text: "D. Robustness to unseen link conditions" },
    { t: "p", text: `Table 6 and Fig. 6(c) report results on the three unseen conditions. On the 160 km, 1 dBm link, which lies inside the training range, LiteOPM-Net keeps ${pm(R.unseen.liteopm.unseen_160km_1dBm.acc, 1, 100)}% accuracy and ${pm(R.unseen.liteopm.unseen_160km_1dBm.mae, 2)} dB OSNR error, the same as on seen links. Format identification also holds on the other two links (above ${Math.floor(100 * Math.min(R.unseen.liteopm.unseen_560km_3dBm.acc[0], R.unseen.liteopm.unseen_80km_2dBm_1MHz.acc[0]))}%), but OSNR error grows.` },
    { t: "table", wide: true, caption: "Table 6: Results on unseen link conditions (mean ± std over three seeds)",
      fr: [1.7, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
      header: ["Model", `${UNL[UN[0]]}: acc. (%)`, "MAE (dB)", `${UNL[UN[1]]}: acc. (%)`, "MAE (dB)", `${UNL[UN[2]]}: acc. (%)`, "MAE (dB)"],
      rows: unRows },
    { t: "cols", n: 2 },
    { t: "p", text: `The 560 km, 3 dBm link shows a basic limit of constellation-based OSNR monitoring. Here fibre nonlinearity adds noise that looks very similar to ASE, and the SNR seen by the receiver saturates: at 30 dB OSNR it is only ${snr30.unseen_560km_3dBm.toFixed(1)} dB, against at least ${minSeenSnr30.toFixed(1)} dB on every training link. A network that reads OSNR from cluster spread therefore underestimates high OSNR on this link, by ${(-u560.bias[u560.bias.length - 1]).toFixed(1)} dB at 30 dB OSNR. Below 20 dB, where ASE still dominates, the error is ${u560.mae_le20.toFixed(2)} dB; above 20 dB it is ${u560.mae_gt20.toFixed(2)} dB. All four models behave the same way on this link, with OSNR errors of ${Math.min(...u560all).toFixed(2)}–${Math.max(...u560all).toFixed(2)} dB, which shows that the limit comes from the data rather than from a particular network. In effect, such monitors measure the total effective SNR, and OSNR can only be recovered from it while ASE is the main noise source. Practical options are to add launch power or span count as side inputs, to train over a wider range of nonlinear conditions, or to adapt the model to a new link with a small amount of data, as in [11].` },
    { t: "p", text: `With a 1 MHz laser linewidth, the pilot-based phase recovery leaves more residual phase noise, which stretches clusters along arcs. The OSNR error stays at ${u1m.mae_le20.toFixed(2)} dB up to 20 dB OSNR but rises to ${u1m.mae_gt20.toFixed(2)} dB above it, where this arc-shaped spread is large compared with the ASE spread the network was trained on. Including several laser linewidths in training is a simple remedy.` },

    { t: "h2", text: "E. Comparison with prior work and limitations" },
    { t: "p", text: `MT-OPMNet [8] reports 97.5% MFI accuracy and an OSNR MAE of 2.41 dB with 0.64 M parameters, while LiteOPM-Net reaches ${pct(L.acc[0])}% and ${L.mae[0].toFixed(2)} dB with ${kfmt(L.params)} parameters. The datasets differ, since [8] covers WDM links of 500–3000 km at two symbol rates, so these figures indicate scale rather than a direct ranking. The two approaches are complementary: constellation images keep phase information that amplitude histograms discard, which helps separate formats with similar amplitude statistics, such as QPSK and 8PSK.` },
    { t: "p", text: "This study has limits. The data are simulated with a single-polarisation, single-channel model; ASE is added once at the receiver; and CD compensation and timing recovery are ideal. Polarisation effects, WDM interference, transceiver imperfections and experimental data are left for future work. The pipeline is designed so that such data can be substituted directly." },

    { t: "h1", text: "VI. Conclusion" },
    { t: "p", text: `This paper presented LiteOPM-Net, a ${kfmt(L.params)}-parameter multi-task CNN that identifies six modulation formats and estimates OSNR from one constellation image. On links simulated with a validated split-step model, it reached ${pct(L.acc[0])}% format accuracy, error-free identification from ${R.first_osnr_100.liteopm} dB OSNR, and ${L.mae[0].toFixed(2)} dB OSNR error, close to baselines that are up to ${Math.round(Math.max(L.params, ...base.map((m) => R.models[m].params)) / L.params)} times larger, and matched two single-task networks at about half their cost. Grad-CAM maps, verified by a deletion test and a region analysis, showed that the network reads formats from cluster positions and OSNR from how far symbols spread into the space around clusters. Tests on unseen links showed that the model transfers well inside the training range, and that nonlinear noise sets a clear limit on OSNR monitoring from constellations alone. Future work will add polarisation and WDM effects, side information on launch power, and validation on experimental data.` },
  ];
}

module.exports = { results, abstract, validationText };
