"""
Place the generated manuscript body inside the IJMOT template (.dotx).

Keeps the template's header (logo and journal title), footers, styles, theme,
fonts and settings; replaces its body with the generated one; inserts Word
(OMML) equations in place of @@EQ:id:n@@ placeholders; and saves a .docx.

    python merge_into_template.py <template.dotx> <body.docx> <out.docx>
"""
import re
import sys
import zipfile
from datetime import datetime, timezone
from xml.sax.saxutils import escape

TPL, BODY, OUT = sys.argv[1:4]
COL_W = 4419                       # column width in DXA (matches build_paper.js)
HDR_REFS = ('<w:headerReference w:type="even" r:id="rId8"/>'
            '<w:headerReference w:type="default" r:id="rId9"/>'
            '<w:footerReference w:type="even" r:id="rId10"/>'
            '<w:footerReference w:type="default" r:id="rId11"/>'
            '<w:headerReference w:type="first" r:id="rId12"/>'
            '<w:footerReference w:type="first" r:id="rId13"/>')

# ------------------------------------------------------------- OMML helpers
MATH_RPR = ('<w:rPr><w:rFonts w:ascii="Cambria Math" w:hAnsi="Cambria Math"/>'
            '<w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>')


def r(t, plain=False):
    sty = '<m:rPr><m:sty m:val="p"/></m:rPr>' if plain else ""
    return f'<m:r>{sty}{MATH_RPR}<m:t xml:space="preserve">{escape(t)}</m:t></m:r>'


def frac(n, d):
    return f"<m:f><m:num>{n}</m:num><m:den>{d}</m:den></m:f>"


def sub(b, s):
    return f"<m:sSub><m:e>{b}</m:e><m:sub>{s}</m:sub></m:sSub>"


def sup(b, s):
    return f"<m:sSup><m:e>{b}</m:e><m:sup>{s}</m:sup></m:sSup>"


def subsup(b, s, p):
    return f"<m:sSubSup><m:e>{b}</m:e><m:sub>{s}</m:sub><m:sup>{p}</m:sup></m:sSubSup>"


def nsum(lo, hi, body):
    hide = "" if hi is not None else '<m:supHide m:val="1"/>'
    return (f'<m:nary><m:naryPr><m:chr m:val="∑"/><m:limLoc m:val="undOvr"/>{hide}</m:naryPr>'
            f"<m:sub>{lo}</m:sub><m:sup>{hi or ''}</m:sup><m:e>{body}</m:e></m:nary>")


def rad(body):
    return f'<m:rad><m:radPr><m:degHide m:val="1"/></m:radPr><m:deg/><m:e>{body}</m:e></m:rad>'


def br(body, beg="(", end=")"):
    return (f'<m:d><m:dPr><m:begChr m:val="{beg}"/><m:endChr m:val="{end}"/></m:dPr>'
            f"<m:e>{body}</m:e></m:d>")


def hat(x):
    return f'<m:acc><m:accPr><m:chr m:val="̂"/></m:accPr><m:e>{r(x)}</m:e></m:acc>'


err_i = sub(hat("o"), r("i")) + r("−") + sub(r("o"), r("i"))
EQ = {
    "nlse": frac(r("∂A"), r("∂z")) + r("=−") + frac(r("α"), r("2")) + r("A−j")
            + frac(sub(r("β"), r("2")), r("2"))
            + frac(sup(r("∂"), r("2")) + r("A"), r("∂") + sup(r("t"), r("2")))
            + r("+jγ") + sup(br(r("A"), "|", "|"), r("2")) + r("A,"),
    "snr": r("SNR=OSNR+10", True) + sub(r("log", True), r("10"))
           + br(frac(sub(r("B"), r("ref", True)), sub(r("R"), r("s")))) + r("  [dB].", True),
    "loss": r("ℒ=−") + r("log", True) + sub(r("p"), r("y")) + r("+λ")
            + br(hat("o") + r("−u"), "|", "|") + r(","),
    "mae": r("MAE", True) + r("=") + frac(r("1"), r("N")) + nsum(r("i=1"), r("N"), br(err_i, "|", "|")) + r(","),
    "rmse": r("RMSE", True) + r("=")
            + rad(frac(r("1"), r("N")) + nsum(r("i=1"), r("N"), sup(br(err_i), r("2")))) + r(","),
    "gcw": sub(r("w"), r("k")) + r("=") + frac(r("1"), r("Z"))
           + nsum(r("i,j"), None, frac(r("∂s"), r("∂") + subsup(r("A"), r("ij"), r("k")))) + r(","),
    "gcm": r("M=") + r("ReLU", True) + br(nsum(r("k"), None, sub(r("w"), r("k")) + sup(r("A"), r("k")))) + r(","),
}


def eq_paragraph(eid, num):
    return ('<w:p><w:pPr><w:keepLines/>'
            f'<w:tabs><w:tab w:val="center" w:pos="{COL_W // 2}"/><w:tab w:val="right" w:pos="{COL_W}"/></w:tabs>'
            '<w:spacing w:before="0" w:after="240" w:line="240" w:lineRule="auto"/></w:pPr>'
            '<w:r><w:tab/></w:r>'
            f"<m:oMath>{EQ[eid]}</m:oMath>"
            '<w:r><w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/>'
            f'<w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr><w:tab/><w:t>({num})</w:t></w:r></w:p>')


# ------------------------------------------------------------- read packages
tz, bz = zipfile.ZipFile(TPL), zipfile.ZipFile(BODY)
files = {n: tz.read(n) for n in tz.namelist()}
doc = bz.read("word/document.xml").decode("utf8")
brels = bz.read("word/_rels/document.xml.rels").decode("utf8")

# equations
used = set()


def eq_sub(m):
    used.add(m.group(1))
    return eq_paragraph(m.group(1), m.group(2))


# state the line rule explicitly (LibreOffice treats a missing rule as "exact" and clips figures)
doc = re.sub(r'(<w:spacing\b(?:(?!w:lineRule)[^>])*w:line="\d+")(\s*/>)', r'\1 w:lineRule="auto"\2', doc)

doc, n_eq = re.subn(r"<w:p>(?:(?!</w:p>).)*?@@EQ:(\w+):(\d+)@@.*?</w:p>", eq_sub, doc, flags=re.S)
assert used == set(EQ), (used, set(EQ))
assert "@@EQ" not in doc

# header/footer references and template page margins in every section
def fix_sect(m):
    s = m.group(0)
    s = re.sub(r"<w:headerReference[^>]*/>|<w:footerReference[^>]*/>", "", s)
    s = re.sub(r"(<w:sectPr\b[^>]*>)", r"\1" + HDR_REFS, s, count=1)
    return s


doc, n_sect = re.subn(r"<w:sectPr\b.*?</w:sectPr>", fix_sect, doc, flags=re.S)

# images: give them new relationship ids and file names
img_rels = re.findall(r'<Relationship Id="([^"]+)" Type="[^"]+/image" Target="([^"]+)"/>', brels)
new_rels = []
for k, (rid, target) in enumerate(img_rels, 1):
    nid, name = f"rIdFig{k}", f"media/fig{k}.png"
    doc = doc.replace(f'r:embed="{rid}"', f'r:embed="{nid}"')
    files["word/" + name] = bz.read("word/" + target.lstrip("/").replace("word/", ""))
    new_rels.append(f'<Relationship Id="{nid}" Type="http://schemas.openxmlformats.org/'
                    f'officeDocument/2006/relationships/image" Target="{name}"/>')
leftover = set(re.findall(r'r:(?:embed|id|link)="([^"]+)"', doc)) - {f"rIdFig{k}" for k in range(1, len(img_rels) + 1)} \
    - {"rId8", "rId9", "rId10", "rId11", "rId12", "rId13"}
assert not leftover, f"unmapped relationships: {leftover}"
for sid in set(re.findall(r'w:(?:pStyle|rStyle|tblStyle) w:val="([^"]+)"', doc)):
    assert f'w:styleId="{sid}"' in files["word/styles.xml"].decode("utf8"), f"style {sid} not in template"

# template relationships: drop the sample e-mail link and sample figure, add ours
rels = files["word/_rels/document.xml.rels"].decode("utf8")
rels = re.sub(r'<Relationship Id="rId7"[^>]*/>', "", rels)
rels = re.sub(r'<Relationship Id="rId14"[^>]*/>', "", rels)
rels = rels.replace("</Relationships>", "".join(new_rels) + "</Relationships>")
files["word/_rels/document.xml.rels"] = rels.encode("utf8")
files.pop("word/media/image2.png", None)           # sample chart, not used by the header

files["word/document.xml"] = doc.encode("utf8")

# .dotx -> .docx
ct = files["[Content_Types].xml"].decode("utf8")
ct = ct.replace("wordprocessingml.template.main+xml", "wordprocessingml.document.main+xml")
files["[Content_Types].xml"] = ct.encode("utf8")

# document properties
now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
core = files["docProps/core.xml"].decode("utf8")
core = re.sub(r"<dc:title>.*?</dc:title>", "<dc:title>An Explainable Lightweight Multi-Task CNN for "
              "Joint Modulation Format Identification and OSNR Monitoring</dc:title>", core)
core = re.sub(r"<dc:creator>.*?</dc:creator>", "<dc:creator>Sanskruti Patel</dc:creator>", core)
core = re.sub(r"<cp:lastModifiedBy>.*?</cp:lastModifiedBy>", "<cp:lastModifiedBy>Sanskruti Patel</cp:lastModifiedBy>", core)
core = re.sub(r"(<dcterms:created[^>]*>).*?(</dcterms:created>)", rf"\g<1>{now}\2", core)
core = re.sub(r"(<dcterms:modified[^>]*>).*?(</dcterms:modified>)", rf"\g<1>{now}\2", core)
files["docProps/core.xml"] = core.encode("utf8")
files.pop("docProps/custom.xml", None)             # "Acrobat PDFMaker" property of the sample
ct = files["[Content_Types].xml"].decode("utf8")
ct = re.sub(r'<Override PartName="/docProps/custom.xml"[^>]*/>', "", ct)
files["[Content_Types].xml"] = ct.encode("utf8")
r0 = files["_rels/.rels"].decode("utf8")
files["_rels/.rels"] = re.sub(r'<Relationship [^>]*Target="docProps/custom.xml"/>', "", r0).encode("utf8")

with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("[Content_Types].xml", files.pop("[Content_Types].xml"))
    for n, data in files.items():
        z.writestr(n, data)
print(f"wrote {OUT}: {n_eq} equations, {n_sect} sections, {len(img_rels)} figures")
