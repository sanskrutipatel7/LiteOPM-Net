// Builds the body of the IJMOT manuscript from content.js + result JSON files.
// Formatting follows the IJMOT template and author guidelines: US Letter,
// 2.5 cm side/bottom margins (top margin as in the template, to clear its
// header logo), 11 pt Times New Roman, two columns with 10 mm gap from the
// abstract onward, plain capital Roman-numeral headings, italic subheadings,
// 10 pt captions, Arial 8 pt tables with 0.25 pt borders, 9 pt references.
// Equations are written as placeholders and replaced with Word (OMML)
// equations by merge_into_template.py, which also places the body inside
// the template file so its header and logo are kept.
const fs = require("fs");
const path = require("path");
const d = require("docx");
const {
  Document, Packer, Paragraph, TextRun, ImageRun, Table, TableRow, TableCell,
  AlignmentType, WidthType, BorderStyle, SectionType, ShadingType, TabStopType,
} = d;

const FONT = "Times New Roman";
const PAGE_W = 12240, PAGE_H = 15840, MARGIN = 1417, GAP = 567, TOP = 1680, HEADER = 759;
const TEXT_W = PAGE_W - 2 * MARGIN;               // 9406 DXA
const COL_W = Math.floor((TEXT_W - GAP) / 2);     // 4419 DXA
const DXA_PER_IN = 1440;

// ------------------------------------------------------------ inline markup
// **bold**  *italic*  ^{sup}  _{sub}
function runs(text, base = {}) {
  const out = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|\^\{[^}]+\}|_\{[^}]+\})/g;
  let last = 0, m;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), font: FONT, ...base }));
    const t = m[0];
    if (t.startsWith("**")) out.push(new TextRun({ text: t.slice(2, -2), bold: true, font: FONT, ...base }));
    else if (t.startsWith("*")) out.push(new TextRun({ text: t.slice(1, -1), italics: true, font: FONT, ...base }));
    else if (t.startsWith("^")) out.push(new TextRun({ text: t.slice(2, -1), superScript: true, font: FONT, ...base }));
    else out.push(new TextRun({ text: t.slice(2, -1), subScript: true, font: FONT, ...base }));
    last = m.index + t.length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), font: FONT, ...base }));
  return out;
}

const SZ = { body: 22, small: 20, ref: 18, title: 36, table: 16 };
const LINE = 240;   // one blank line between paragraphs (template rule)

function para(text, o = {}) {
  return new Paragraph({
    alignment: o.align ?? AlignmentType.JUSTIFIED,
    spacing: { after: o.after ?? LINE, before: o.before ?? 0, line: o.line ?? 240 },
    keepNext: o.keepNext, indent: o.indent,
    children: runs(text, { size: o.size ?? SZ.body, bold: o.bold, italics: o.italics }),
  });
}

function heading1(text) {
  return new Paragraph({
    alignment: AlignmentType.CENTER, keepNext: true,
    spacing: { before: LINE, after: LINE, line: 240 },
    children: [new TextRun({ text: text.toUpperCase(), font: FONT, size: SZ.body })],
  });
}
function heading2(text) {
  return new Paragraph({
    alignment: AlignmentType.LEFT, keepNext: true, spacing: { before: 0, after: 200, line: 240 },
    children: [new TextRun({ text, font: FONT, size: SZ.body, italics: true })],
  });
}

function figure(file, widthIn, caption, wide) {
  const buf = fs.readFileSync(path.join(__dirname, "..", "figs", file));
  // PNG size from header
  const w = buf.readUInt32BE(16), h = buf.readUInt32BE(20);
  const maxIn = wide ? TEXT_W / DXA_PER_IN : COL_W / DXA_PER_IN;
  const wi = Math.min(widthIn, maxIn);
  const px = wi * 96;
  return [
    new Paragraph({
      alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 120, after: 120, line: 240 },
      children: [new ImageRun({ type: "png", data: buf,
        transformation: { width: Math.round(px), height: Math.round(px * h / w) } })],
    }),
    para(caption, { size: SZ.small, align: wide ? AlignmentType.CENTER : AlignmentType.JUSTIFIED, after: LINE }),
  ];
}

function table(caption, header, rows, o = {}) {
  const width = o.wide ? TEXT_W : COL_W;
  const ncol = header.length;
  const fr = o.fr ?? Array(ncol).fill(1);
  const tot = fr.reduce((a, b) => a + b, 0);
  const cw = fr.map((f) => Math.floor((width * f) / tot));
  cw[cw.length - 1] += width - cw.reduce((a, b) => a + b, 0);
  const line = { style: BorderStyle.SINGLE, size: 2, color: "000000" };   // 0.25 pt grid
  const noteNext = o.note;
  const mk = (cells, isHead, isLast, bold) => new TableRow({
    tableHeader: isHead, cantSplit: true,
    children: cells.map((c, i) => new TableCell({
      width: { size: cw[i], type: WidthType.DXA },
      margins: { top: 30, bottom: 30, left: 60, right: 60 },
      borders: { top: line, bottom: line, left: line, right: line },
      children: [new Paragraph({
        keepNext: !isLast || !!noteNext, keepLines: true, spacing: { before: 0, after: 0, line: 240 },
        alignment: i === 0 ? AlignmentType.LEFT : AlignmentType.CENTER,
        children: runs(String(c), { size: SZ.table, font: "Arial", bold: !isHead && bold && bold[i] }),
      })],
    })),
  });
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 120, after: 120, line: 240 },
      children: runs(caption, { size: SZ.small }) }),
    new Table({ width: { size: width, type: WidthType.DXA }, columnWidths: cw,
      alignment: AlignmentType.CENTER,
      rows: [mk(header, true, false), ...rows.map((r, i) => mk(r.cells ?? r, false, i === rows.length - 1, r.bold))] }),
    para(o.note ?? "", { size: SZ.table, after: LINE, align: AlignmentType.LEFT }),
  ];
}

// placeholder; replaced by a Word equation in merge_into_template.py
function equation(id, num) {
  return new Paragraph({ spacing: { after: LINE, line: 240 },
    children: [new TextRun({ text: `@@EQ:${id}:${num}@@`, font: FONT, size: SZ.body })] });
}

// ------------------------------------------------------------ build
const C = require("./content.js");
const blocks = C.blocks();
const sections = [];
let cur = null;
const props = (cols, cont) => ({
  page: { size: { width: PAGE_W, height: PAGE_H },
          margin: { top: TOP, bottom: MARGIN, left: MARGIN, right: MARGIN, header: HEADER } },
  type: cont ? SectionType.CONTINUOUS : undefined,
  column: cols === 2 ? { count: 2, space: GAP, equalWidth: true } : { count: 1 },
});
function open(cols) {
  cur = { properties: props(cols, sections.length > 0), children: [], cols };
  sections.push(cur);
}

open(1);
for (const b of blocks) {
  switch (b.t) {
    case "cols":
      if (!(cur.cols === b.n && cur.children.length === 0)) open(b.n);
      break;
    case "title": cur.children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 400, after: LINE, line: 240 },
      children: [new TextRun({ text: b.text, font: FONT, size: SZ.title, bold: true })] })); break;
    case "authors": cur.children.push(para(b.text, { align: AlignmentType.CENTER, after: LINE })); break;
    case "affil": cur.children.push(para(b.text, { align: AlignmentType.CENTER, size: SZ.small, after: b.after ?? 0 })); break;
    case "abstract": cur.children.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: LINE, line: 240 },
      children: [new TextRun({ text: "Abstract-", font: FONT, size: SZ.small, bold: true, italics: true }),
                 ...runs(b.text, { size: SZ.small, bold: true })] })); break;
    case "index": cur.children.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 2 * LINE, line: 240 },
      children: [new TextRun({ text: "Index Terms- ", font: FONT, size: SZ.small, bold: true, italics: true }),
                 ...runs(b.text, { size: SZ.small, bold: true })] })); break;
    case "h1": cur.children.push(heading1(b.text)); break;
    case "h2": cur.children.push(heading2(b.text)); break;
    case "p": cur.children.push(para(b.text, b.o ?? {})); break;
    case "list": b.items.forEach((it, i) => cur.children.push(para(`${i + 1})  ${it}`,
      { indent: { left: 280, hanging: 280 }, after: i === b.items.length - 1 ? LINE : 80 }))); break;
    case "eq": cur.children.push(equation(b.id, b.n)); break;
    case "fig":
      if (b.wide) open(1);
      cur.children.push(...figure(b.file, b.w, b.caption, b.wide));
      if (b.wide) open(2);
      break;
    case "table":
      if (b.wide) open(1);
      cur.children.push(...table(b.caption, b.header, b.rows, b));
      if (b.wide) open(2);
      break;
    case "refs": b.items.forEach((r, i) => cur.children.push(new Paragraph({
      alignment: AlignmentType.JUSTIFIED, indent: { left: 400, hanging: 400 }, spacing: { after: 40, line: 240 },
      children: [new TextRun({ text: `[${i + 1}]\t`, font: FONT, size: SZ.ref }), ...runs(r, { size: SZ.ref })],
      tabStops: [{ type: TabStopType.LEFT, position: 400 }] }))); break;
    default: throw new Error("unknown block " + b.t);
  }
}

// drop empty sections (e.g. a 2-column section immediately followed by a wide item)
for (let i = sections.length - 1; i > 0; i--) if (sections[i].children.length === 0) sections.splice(i, 1);
for (const sct of sections) delete sct.cols;
const doc = new Document({
  creator: C.meta.author, title: C.meta.title,
  styles: { default: { document: { run: { font: FONT, size: SZ.body } } } },
  sections,
});
Packer.toBuffer(doc).then((buf) => {
  const out = path.join(__dirname, "body_" + C.meta.file);
  fs.writeFileSync(out, buf);
  console.log("wrote", out);
});
