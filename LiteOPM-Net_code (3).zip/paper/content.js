// Manuscript text. Every result number is read from the JSON files written by
// analyze.py, xai.py and validate_sim.py, never typed by hand.
const fs = require("fs");
const path = require("path");
const ROOT = path.join(__dirname, "..");
const J = (p) => JSON.parse(fs.readFileSync(path.join(ROOT, p), "utf8"));

const meta = {
  title: "An Explainable Lightweight Multi-Task CNN for Joint Modulation Format Identification and OSNR Monitoring in Coherent Optical Links",
  author: "Sanskruti Patel",
  file: "IJMOT_LiteOPM-Net_manuscript.docx",
};

const f1 = (x) => x.toFixed(1), f2 = (x) => x.toFixed(2), pct = (x) => (100 * x).toFixed(1);
const pm = (ms, k = 1, s = 1) => `${(ms[0] * s).toFixed(k)} ± ${(ms[1] * s).toFixed(k)}`;
const kfmt = (n) => (n >= 1e6 ? (n / 1e6).toFixed(2) + " M" : (n / 1e3).toFixed(1) + " k");

const REFS = [
  "Z. Dong, F. N. Khan, Q. Sui, K. Zhong, C. Lu, and A. P. T. Lau, “Optical performance monitoring: A review of current and future technologies”, *J. Lightw. Technol.*, Vol. 34, No. 2, pp. 525–543, 2016.",
  "W. S. Saif, M. A. Esmail, A. M. Ragheb, T. A. Alshawi, and S. A. Alshebeili, “Machine learning techniques for optical performance monitoring and modulation format identification: A survey”, *IEEE Commun. Surveys Tuts.*, Vol. 22, No. 4, pp. 2839–2882, 2020.",
  "F. N. Khan, K. Zhong, W. H. Al-Arashi, C. Yu, C. Lu, and A. P. T. Lau, “Modulation format identification in coherent receivers using deep machine learning”, *IEEE Photon. Technol. Lett.*, Vol. 28, No. 17, pp. 1886–1889, 2016.",
  "D. Wang, M. Zhang, Z. Li, *et al.*, “Modulation format recognition and OSNR estimation using CNN-based deep learning”, *IEEE Photon. Technol. Lett.*, Vol. 29, No. 19, pp. 1667–1670, 2017.",
  "F. N. Khan, K. Zhong, X. Zhou, W. H. Al-Arashi, C. Yu, C. Lu, and A. P. T. Lau, “Joint OSNR monitoring and modulation format identification in digital coherent receivers using deep neural networks”, *Opt. Express*, Vol. 25, No. 15, pp. 17767–17776, 2017.",
  "X. Fan, Y. Xie, F. Ren, *et al.*, “Joint optical performance monitoring and modulation format/bit-rate identification by CNN-based multi-task learning”, *IEEE Photon. J.*, Vol. 10, No. 5, Art. no. 7906712, 2018.",
  "X. Fan, L. Wang, F. Ren, *et al.*, “Feature-fusion-based multi-task ConvNet for simultaneous optical performance monitoring and bit-rate/modulation format identification”, *IEEE Access*, Vol. 7, pp. 126709–126719, 2019.",
  "Y. Al-Karawi, A. M. Jasim, R. S. Alhumaima, and H. S. Al-Raweshidy, “MT-OPMNet: Attention-enhanced multi-task deep learning for joint OSNR estimation and modulation format recognition in elastic optical networks”, *IET Netw.*, Vol. 15, Art. no. e70038, 2026.",
  "O. Ayoub, S. Troia, D. Andreoletti, A. Bianco, M. Tornatore, S. Giordano, and C. Rottondi, “Towards explainable artificial intelligence in optical networks: The use case of lightpath QoT estimation”, *J. Opt. Commun. Netw.*, Vol. 15, No. 1, pp. 26–38, 2023.",
  "R. R. Selvaraju, M. Cogswell, A. Das, R. Vedantam, D. Parikh, and D. Batra, “Grad-CAM: Visual explanations from deep networks via gradient-based localization”, in *Proc. IEEE Int. Conf. Comput. Vis. (ICCV)*, 2017, pp. 618–626.",
  "L. Xia, J. Zhang, S. Hu, M. Zhu, Y. Song, and K. Qiu, “Transfer learning assisted deep neural network for OSNR estimation”, *Opt. Express*, Vol. 27, No. 14, pp. 19398–19406, 2019.",
  "V. Petsiuk, A. Das, and K. Saenko, “RISE: Randomized input sampling for explanation of black-box models”, in *Proc. British Mach. Vis. Conf. (BMVC)*, 2018.",
  "G. P. Agrawal, *Nonlinear Fiber Optics*, 5th ed. Oxford, U.K.: Academic Press, 2013.",
  "P. Poggiolini, “The GN model of non-linear propagation in uncompensated coherent optical systems”, *J. Lightw. Technol.*, Vol. 30, No. 24, pp. 3857–3879, 2012.",
  "A. G. Howard, M. Zhu, B. Chen, D. Kalenichenko, W. Wang, T. Weyand, M. Andreetto, and H. Adam, “MobileNets: Efficient convolutional neural networks for mobile vision applications”, arXiv:1704.04861, 2017.",
  "M. Sandler, A. Howard, M. Zhu, A. Zhmoginov, and L.-C. Chen, “MobileNetV2: Inverted residuals and linear bottlenecks”, in *Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit. (CVPR)*, 2018, pp. 4510–4520.",
  "K. He, X. Zhang, S. Ren, and J. Sun, “Deep residual learning for image recognition”, in *Proc. IEEE Conf. Comput. Vis. Pattern Recognit. (CVPR)*, 2016, pp. 770–778.",
];

function blocks() {
  const R = J("results.json");
  const X = J("runs/liteopm_both_s0/xai.json");
  const V = J("validation.json");
  const L = R.models.liteopm;
  const S = require("./content_results.js");
  const U = J("rerun_colab_results.json");
  const zs = [];
  const z = (r, u) => zs.push(Math.abs(u[0] - r[0]) / Math.max(r[1], u[1], 1e-9));
  for (const m of Object.keys(R.models)) {
    for (const k of ["acc", "acc_low", "mae", "rmse"]) z(R.models[m][k], U.models[m][k]);
    for (const c of Object.keys(R.unseen[m])) { z(R.unseen[m][c].acc, U.unseen[m][c].acc); z(R.unseen[m][c].mae, U.unseen[m][c].mae); }
  }
  z(R.ablation.mfi.acc, U.ablation.mfi.acc); z(R.ablation.osnr.mae, U.ablation.osnr.mae);
  const zmax = Math.max(...zs);
  const zlim = Math.ceil(zmax * 2) / 2;
  const rerunText = `As an independent check, all 18 training runs were repeated on a cloud GPU; every accuracy and OSNR error in Tables 3, 4 and 6 changed by less than ${zlim.toFixed(1)} seed standard deviations (largest change ${zmax.toFixed(1)}).`;
  return [
    { t: "title", text: meta.title },
    { t: "authors", text: "Sanskruti Patel^{*}" },
    { t: "affil", text: "Faculty of Computer Science and Applications, Smt. Chandaben Mohanbhai Patel Institute of Computer Applications (CMPICA), Charotar University of Science and Technology (CHARUSAT), Changa, Anand, Gujarat 388421, India" },
    { t: "affil", text: "E-mail: sanskrutipatel.mca@charusat.ac.in", after: 360 },
    { t: "cols", n: 2 },
    { t: "abstract", text: S.abstract(R, X) },
    { t: "index", text: "explainable AI, Grad-CAM, modulation format identification, multi-task learning, optical performance monitoring, OSNR estimation" },

    // ---------------------------------------------------------------- I
    { t: "h1", text: "I. Introduction" },
    { t: "p", text: "Elastic optical networks change modulation format, symbol rate and route on demand to use fibre capacity efficiently. A monitoring node in such a network often does not know in advance which modulation format is arriving, and the network controller needs a running estimate of signal quality to decide whether a lightpath can keep its format or must step down to a more robust one. Optical performance monitoring (OPM) supplies this information, and two of its most basic tasks are modulation format identification (MFI) and estimation of the optical signal-to-noise ratio (OSNR) [1], [2]." },
    { t: "p", text: "Deep learning is now the standard tool for both tasks. Early work used deep neural networks on amplitude histograms [3], while convolutional neural networks (CNNs) on eye or constellation diagrams treat monitoring as an image problem [4]. Later studies showed that one network with two output heads can solve MFI and OSNR estimation together, because the same features describe both the layout of a constellation and the spread of its clusters [5]–[7]. Most recently, MT-OPMNet [8] combined a 1D CNN on amplitude histograms with channel attention and shared layers." },
    { t: "p", text: "Three gaps remain. First, many models are large, although monitors are meant to sit at many nodes on low-cost hardware. Second, the models are black boxes: operators are unlikely to act on an alarm they cannot explain, and the few explainability studies in optical networking either explain other tasks [9] or show gradient saliency without checking whether it is faithful to the model [8]. Third, models are usually tested only on the link conditions they were trained on. This paper addresses these gaps with the following contributions:" },
    { t: "list", items: [
      `A lightweight multi-task CNN, LiteOPM-Net, that identifies six formats and estimates OSNR from one 64 × 64 constellation image using ${kfmt(L.params)} parameters and ${(L.macs / 1e6).toFixed(1)} M multiply-accumulate operations (MACs).`,
      "A comparison with an AlexNet-style CNN, MobileNetV2 and ResNet-18 under identical data and training, covering accuracy, OSNR error, size, compute and CPU latency over three random seeds.",
      "A Grad-CAM [10] analysis that is verified twice: a deletion test for faithfulness, and a region analysis that checks whether each head looks where communication theory says it should.",
      "A robustness test on three link conditions never used in training, and an open, physics-validated Python pipeline that reproduces every result.",
    ] },

    // ---------------------------------------------------------------- II
    { t: "h1", text: "II. Related Work" },
    { t: "p", text: "Dong *et al.* [1] review OPM before and after coherent detection, and Saif *et al.* [2] survey machine learning for OPM and MFI. Khan *et al.* [3] identified formats in coherent receivers with a deep neural network on amplitude histograms and later added joint OSNR monitoring [5]. Wang *et al.* [4] applied a CNN to eye diagrams for format recognition and OSNR estimation. Fan *et al.* [6] used multi-task learning on asynchronous delay-tap phase portraits, and a feature-fusion variant followed [7]. Xia *et al.* [11] used transfer learning to adapt an OSNR estimator to new links." },
    { t: "p", text: "MT-OPMNet [8] is the closest work. It shares a 1D CNN between an OSNR head and an MFI head on 100-bin amplitude histograms, uses about 0.64 M parameters, and reports 97.5% MFI accuracy and an OSNR mean absolute error (MAE) of 2.41 dB over a wide range of wavelength-division multiplexed (WDM) links. Its explainability is limited to gradient saliency over histogram bins. In optical networking more broadly, Ayoub *et al.* [9] used SHAP to explain a quality-of-transmission classifier. In computer vision, Grad-CAM [10] shows which image regions a CNN uses, and deletion tests [12] check whether such maps are faithful. We are not aware of constellation-based OPM work that combines Grad-CAM with a faithfulness test and a physics-based region analysis. Table 1 summarises the position of this work." },
    { t: "table", caption: "Table 1: Comparison with related deep learning OPM work", fr: [1.2, 1.3, 0.9, 0.95, 1.4],
      header: ["Work", "Input", "Tasks", "Params", "XAI"],
      rows: [
        ["Khan [3]", "Amplitude histogram", "MFI", "n/r", "None"],
        ["Wang [4]", "Eye diagram", "MFI, OSNR", "n/r", "None"],
        ["Fan [6]", "Delay-tap portrait", "MFI, OPM", "n/r", "None"],
        ["MT-OPMNet [8]", "Amplitude histogram", "MFI, OSNR", "0.64 M", "Saliency"],
        { cells: ["This work", "Constellation image", "MFI, OSNR", kfmt(L.params), "Grad-CAM, verified"], bold: [true] },
      ], note: "XAI: explanation method used; n/r: not reported." },

    // ---------------------------------------------------------------- III
    { t: "h1", text: "III. System Model and Dataset" },
    { t: "h2", text: "A. Simulated link" },
    { t: "p", text: "Fig. 1 shows the simulated link and Table 2 its parameters. The transmitter draws random symbols from QPSK, 8PSK, star 8QAM (ring ratio 1 + √3), square 16QAM, cross 32QAM or square 64QAM. Every 32nd symbol is a known QPSK pilot. Symbols are shaped by a root-raised-cosine (RRC) filter and passed through Wiener laser phase noise. Each 80 km span of standard single-mode fibre (SSMF) is solved with the symmetric split-step Fourier method (SSFM) on the scalar nonlinear Schrödinger equation [13]," },
    { t: "eq", id: "nlse", text: "∂A/∂z = −(α/2)A − j(β_{2}/2)∂^{2}A/∂t^{2} + jγ|A|^{2}A,", n: 1 },
    { t: "p", text: "followed by an erbium-doped fibre amplifier (EDFA) that restores the span loss. At the receiver, amplified spontaneous emission (ASE) noise is added to set the OSNR exactly in the 0.1 nm (12.5 GHz) reference bandwidth *B*_{ref}. For a dual-polarisation signal at symbol rate *R*_{s}, the noise-only signal-to-noise ratio (SNR) after matched filtering is" },
    { t: "eq", id: "snr", text: "SNR = OSNR + 10 log_{10}(B_{ref}/R_{s})  [dB].", n: 2 },
    { t: "p", text: "The receiver applies ideal chromatic dispersion (CD) compensation, an RRC matched filter and down-sampling. Carrier phase is recovered from the pilots by averaging the pilot phase error over nine pilots, unwrapping and interpolating. Unlike blind estimators, this does not need to know the data format, which is essential for a format identifier. After removing pilots, 4,096 data symbols are normalised to unit power and counted in a 64 × 64 grid over ±1.9 on both axes; log(1 + *n*) compresses dense bins and the result is stored as an 8-bit image (Fig. 2)." },
    { t: "fig", file: "fig1_link.png", w: 6.5, wide: true, caption: "Fig. 1. Simulated coherent link and monitoring chain." },
    { t: "fig", file: "fig3_constellations.png", w: 5.3, wide: true, caption: "Fig. 2. Example constellation images after 400 km at 2 dBm launch power. At 30 dB OSNR the outer points of 8QAM and 16QAM are stretched along the phase direction by fibre nonlinearity." },
    { t: "cols", n: 2 },
    { t: "table", caption: "Table 2: Simulation parameters", fr: [1.6, 1.2],
      header: ["Parameter", "Value"],
      rows: [
        ["Symbol rate, pulse shape", "32 GBaud, RRC 0.1"],
        ["Samples per symbol", "4"],
        ["Pilot rate, phase-recovery window", "1/32, 9 pilots"],
        ["Laser linewidth (Tx + local osc.)", "100 kHz"],
        ["Span length, loss", "80 km, 0.2 dB/km"],
        ["Dispersion", "17 ps/(nm·km)"],
        ["Nonlinear coefficient γ", "1.3 W^{−1}km^{−1}"],
        ["SSFM step", "1 km"],
        ["OSNR range", "10–30 dB, 1 dB steps"],
        ["Symbols per image", "4,096"],
      ] },
    { t: "h2", text: "B. Validation of the simulator" },
    { t: "p", text: S.validationText(V) },
    { t: "h2", text: "C. Dataset" },
    { t: "p", text: "Nine link conditions were simulated. Six *seen* conditions combine 80, 240 and 400 km with launch powers of 0 and 2 dBm and are used for training, validation and testing. Three *unseen* conditions are used only for the robustness test: 160 km at 1 dBm (inside the training range), 560 km at 3 dBm (longer and more nonlinear than any training link) and 80 km at 2 dBm with a 1 MHz linewidth (ten times wider than in training). For each condition, format and integer OSNR from 10 to 30 dB, 10 images were generated: 1,260 images per condition and 11,340 in total. The seen data were split within every (condition, format, OSNR) group into 70% training, 10% validation and 20% test images." },
    { t: "cols", n: 2 },

    // ---------------------------------------------------------------- IV
    { t: "h1", text: "IV. Proposed Method" },
    { t: "h2", text: "A. LiteOPM-Net" },
    { t: "p", text: `Fig. 3 shows the network. A 3 × 3 convolution with 16 channels is followed by four depthwise-separable (DS) blocks [15] with 32, 64, 96 and 128 channels. Each DS block applies a 3 × 3 depthwise and a 1 × 1 pointwise convolution, each with batch normalisation and ReLU. Only the first two blocks use stride 2, so the last two keep 16 × 16 feature maps; this preserves spatial detail for Grad-CAM at little cost. Global average pooling gives a 128-dimensional vector shared by a softmax MFI head and a two-layer OSNR regressor with 64 hidden units. The model has ${L.params.toLocaleString("en-US")} parameters.` },
    { t: "p", text: "Let *p*_{c} be the softmax output for format *c*, *y* the true format, *o* the true OSNR in dB and *ô* the regression output. With the normalised target *u* = (*o* − 20)/10, the training loss is" },
    { t: "eq", id: "loss", text: "ℒ = −log *p*_{y} + λ|*ô* − *u*|,", n: 3 },
    { t: "p", text: "with λ = 1. The OSNR estimate is made without knowing the format, so MFI errors can affect it, as in a real monitor." },
    { t: "fig", file: "fig2_model.png", w: 6.5, wide: true, caption: "Fig. 3. Architecture of the proposed LiteOPM-Net." },
    { t: "cols", n: 2 },
    { t: "h2", text: "B. Baselines and training" },
    { t: "p", text: `Three baselines receive the same input and the same two heads: an AlexNet-style CNN with five convolutional layers in the spirit of early CNN-based OPM [4], MobileNetV2 [16] and ResNet-18 [17]. The last two come from torchvision with a one-channel first layer and no pre-trained weights. MFI-only and OSNR-only versions of LiteOPM-Net are trained for an ablation study. All models are trained for 30 epochs with AdamW (weight decay 10^{−4}), batch size 64 and a one-cycle schedule with peak learning rate 2 × 10^{−3} for LiteOPM-Net and 10^{−3} for the baselines. The epoch with the best validation score, (1 − accuracy) + MAE/5, is kept. Each model is trained with three seeds and results are given as mean ± standard deviation. Latency is measured on one CPU thread at batch size 1. All models were implemented in PyTorch 2.14 and trained on a two-core CPU without a GPU, using one thread per run, which makes every run exactly repeatable. ${rerunText}` },
    { t: "p", text: "MFI is scored by accuracy. OSNR is scored by the mean absolute error (MAE) and root-mean-square error (RMSE) over *N* test images," },
    { t: "eq", id: "mae", text: "MAE = (1/*N*) Σ_{i} |*ô*_{i} − *o*_{i}|,", n: 4 },
    { t: "eq", id: "rmse", text: "RMSE = [(1/*N*) Σ_{i} (*ô*_{i} − *o*_{i})^{2}]^{1/2},", n: 5 },
    { t: "p", text: "where *ô*_{i} is the estimate in dB." },
    { t: "h2", text: "C. Grad-CAM and its verification" },
    { t: "p", text: "For a target output *s* and the *K* feature maps *A*^{k} of the last DS block, Grad-CAM [10] weights each map by its average gradient:" },
    { t: "eq", id: "gcw", text: "*w*_{k} = (1/*Z*) Σ_{i,j} ∂*s*/∂*A*^{k}_{ij},", n: 6 },
    { t: "eq", id: "gcm", text: "*M* = ReLU(Σ_{k} *w*_{k} *A*^{k}),", n: 7 },
    { t: "p", text: "where *Z* = 16 × 16 is the map size. *M* is upsampled to 64 × 64 and scaled to [0, 1]. For the MFI head the target *s* is the logit of the predicted format. For the OSNR head two maps are computed, one for the positive output (evidence that raises the estimate) and one for the negative output (evidence that lowers it)." },
    { t: "p", text: "Faithfulness is tested by deletion [12]: the top *k*% of pixels ranked by Grad-CAM are set to zero for *k* = 0–50%, and accuracy and OSNR error are recorded, alongside the same test with random pixel order. A faithful map should damage predictions faster than random deletion." },
    { t: "p", text: "Physical meaning is tested by a region analysis. For each image, the ideal constellation points are scaled by the signal share of received power, and the per-dimension noise standard deviation σ is obtained from the measured SNR. Pixels within σ of an ideal point form the *core*, pixels between σ and 2.5σ the *halo*, and the rest the *gaps*. Theory suggests that format identification should rely on where clusters are, and OSNR on how far symbols spread out of them. The share of each map's mass in a region is divided by the region's share of image area; values above 1 mean the map concentrates there." },

    ...S.results(R, X, pm, pct, f1, f2, kfmt),
    { t: "h1", text: "Acknowledgment" },
    { t: "p", text: "The author used Claude (Anthropic), an AI assistant, to help write the simulation, training and analysis code, to run the experiments and to draft the manuscript. The author checked the code and results, independently re-ran all experiments, reviewed and revised the text, and takes full responsibility for the content of this paper." },
    { t: "p", text: "The simulation and training code, the generated dataset and the trained models are available from the corresponding author on reasonable request." },
    { t: "h1", text: "References" },
    { t: "refs", items: REFS },
  ];
}

module.exports = { blocks, meta };
