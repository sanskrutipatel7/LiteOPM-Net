"""Dataset loading and splitting for the IJMOT study."""
import glob
import json
import os

import numpy as np

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
OSNR_MEAN, OSNR_SCALE = 20.0, 10.0          # target normalisation for regression


def load(pattern):
    """Load and concatenate every npz in data/ matching the glob pattern."""
    files = sorted(f for f in glob.glob(os.path.join(DATA_DIR, pattern))
                   if not f.endswith(".tmp.npz"))
    if not files:
        raise FileNotFoundError(pattern)
    X, F, O, S, C = [], [], [], [], []
    for ci, f in enumerate(files):
        d = np.load(f)
        X.append(d["images"]); F.append(d["fmt"]); O.append(d["osnr"])
        S.append(d["snr_eff"]); C.append(np.full(len(d["fmt"]), ci))
        meta = json.loads(str(d["meta"]))
    names = [os.path.basename(f)[:-4] for f in files]
    return dict(x=np.concatenate(X), fmt=np.concatenate(F).astype(np.int64),
                osnr=np.concatenate(O).astype(np.float32),
                snr=np.concatenate(S).astype(np.float32),
                cond=np.concatenate(C), cond_names=names,
                formats=meta["formats"])


def split(d, seed=0, frac=(0.70, 0.10, 0.20)):
    """Stratified split by (condition, format, OSNR)."""
    rng = np.random.default_rng(seed)
    key = d["cond"] * 10000 + d["fmt"] * 100 + d["osnr"].astype(int)
    tr, va, te = [], [], []
    for k in np.unique(key):
        idx = rng.permutation(np.flatnonzero(key == k))
        n_tr = int(round(frac[0] * len(idx)))
        n_va = int(round(frac[1] * len(idx)))
        tr += list(idx[:n_tr]); va += list(idx[n_tr:n_tr + n_va])
        te += list(idx[n_tr + n_va:])
    return np.array(tr), np.array(va), np.array(te)
