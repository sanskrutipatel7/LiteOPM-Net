#!/bin/bash
# Train every model, 3 seeds each, two single-thread jobs at a time.
# Skips runs that already finished (so it can be restarted safely).
cd "$(dirname "$0")"
jobs_list=()
for s in 0 1 2; do
  jobs_list+=("liteopm both $s 2e-3")
  jobs_list+=("liteopm mfi $s 2e-3")
  jobs_list+=("liteopm osnr $s 2e-3")
done
for s in 0 1 2; do
  jobs_list+=("mobilenetv2 both $s 1e-3")
  jobs_list+=("alexstyle both $s 1e-3")
  jobs_list+=("resnet18 both $s 1e-3")
done

run_one () {
  set -- $1
  dir="runs/${1}_${2}_s${3}"
  if [ -f "$dir/info.json" ]; then echo "skip $dir"; return; fi
  mkdir -p "$dir"
  echo "$(date +%T) start $dir"
  python3 train.py --model $1 --task $2 --seed $3 --lr $4 --threads 1 > "$dir/train.log" 2>&1
  echo "$(date +%T) done  $dir ($(tail -c 200 $dir/train.log | grep -o '"train_time_s": [0-9.]*'))"
}
export -f run_one
printf "%s\n" "${jobs_list[@]}" | xargs -P 2 -I{} bash -c 'run_one "{}"'
echo "$(date +%T) ALL TRAINING DONE"
