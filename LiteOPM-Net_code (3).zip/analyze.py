"""
Aggregate all training runs into the paper's tables (results.json) and
figures (figs/). Run after train.py runs and xai.py have finished.
"""
import glob
import json
import os
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

from data import load
from models import build

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
                     "font.size": 8, "axes.linewidth": 0.6, "axes.spines.top": False,
                     "axes.spines.right": False, "legend.frameon": False})
HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.path.join(HERE, "figs")
NAMES = {"liteopm": "LiteOPM-Net (proposed)", "alexstyle": "AlexNet-style CNN",
         "resnet18": "ResNet-18", "mobilenetv2": "MobileNetV2"}
COLORS = {"liteopm": "#c0392b", "alexstyle": "#7f8c8d", "resnet18": "#2e6da4",
          "mobilenetv2": "#27865f"}
ORDER = ["liteopm", "alexstyle", "mobilenetv2", "resnet18"]
UNSEEN_LABEL = {"unseen_160km_1dBm": "160 km, 1 dBm",
                "unseen_560km_3dBm": "560 km, 3 dBm",
                "unseen_80km_2dBm_1MHz": "80 km, 1 MHz laser"}


def metrics(fp, op, f, o):
    err = op - o
    return dict(acc=float((fp == f).mean()), mae=float(np.abs(err).mean()),
                rmse=float(np.sqrt((err ** 2).mean())))


def latency_ms(name, task="both", n=300):
    torch.set_num_threads(1)
    m = build(name, task).eval()
    x = torch.rand(1, 1, 64, 64)
    with torch.no_grad():
        for _ in range(30):
            m(x)
        t = time.perf_counter()
        for _ in range(n):
            m(x)
    return (time.perf_counter() - t) / n * 1e3


def mean_std(vals):
    v = np.array(vals, float)
    return [float(v.mean()), float(v.std(ddof=1)) if len(v) > 1 else 0.0]


def main():
    runs = {}
    for p in sorted(glob.glob(os.path.join(HERE, "runs", "*", "info.json"))):
        info = json.load(open(p))
        pr = dict(np.load(os.path.join(os.path.dirname(p), "preds.npz")))
        runs.setdefault((info["model"], info["task"]), []).append((info, pr))

    res = {"models": {}, "ablation": {}, "per_osnr": {}, "unseen": {}}
    osnr_grid = np.arange(10, 31)
    for (m, task), lst in runs.items():
        seen = [metrics(pr["seen_fmt_pred"], pr["seen_osnr_pred"], pr["seen_fmt"],
                        pr["seen_osnr"]) for _, pr in lst]
        low = [metrics(pr["seen_fmt_pred"][pr["seen_osnr"] <= 14],
                       pr["seen_osnr_pred"][pr["seen_osnr"] <= 14],
                       pr["seen_fmt"][pr["seen_osnr"] <= 14],
                       pr["seen_osnr"][pr["seen_osnr"] <= 14]) for _, pr in lst]
        entry = dict(n_seeds=len(lst), params=lst[0][0]["params"], macs=lst[0][0]["macs"],
                     train_time_s=mean_std([i["train_time_s"] for i, _ in lst]),
                     acc=mean_std([s["acc"] for s in seen]),
                     acc_low=mean_std([s["acc"] for s in low]),
                     mae=mean_std([s["mae"] for s in seen]),
                     rmse=mean_std([s["rmse"] for s in seen]))
        if task == "both":
            entry["latency_ms"] = latency_ms(m)
            res["models"][m] = entry
            # accuracy and MAE vs OSNR (pooled over seeds)
            fp = np.concatenate([pr["seen_fmt_pred"] for _, pr in lst])
            f = np.concatenate([pr["seen_fmt"] for _, pr in lst])
            op = np.concatenate([pr["seen_osnr_pred"] for _, pr in lst])
            o = np.concatenate([pr["seen_osnr"] for _, pr in lst])
            res["per_osnr"][m] = dict(
                acc=[float((fp[o == k] == f[o == k]).mean()) for k in osnr_grid],
                mae=[float(np.abs(op[o == k] - k).mean()) for k in osnr_grid])
            # unseen conditions
            cond_names = lst[0][0]["unseen_conditions"]
            un = {}
            for ci, cn in enumerate(cond_names):
                ms = [metrics(pr["unseen_fmt_pred"][pr["unseen_cond"] == ci],
                              pr["unseen_osnr_pred"][pr["unseen_cond"] == ci],
                              pr["unseen_fmt"][pr["unseen_cond"] == ci],
                              pr["unseen_osnr"][pr["unseen_cond"] == ci]) for _, pr in lst]
                un[cn] = dict(acc=mean_std([q["acc"] for q in ms]),
                              mae=mean_std([q["mae"] for q in ms]))
            res["unseen"][m] = un
        if m == "liteopm":
            res["ablation"][task] = entry
    # OSNR bias (pred - true) vs OSNR on unseen links, proposed model, pooled seeds
    lst = runs[("liteopm", "both")]
    res["unseen_bias"] = {}
    for ci, cn in enumerate(lst[0][0]["unseen_conditions"]):
        o = np.concatenate([pr["unseen_osnr"][pr["unseen_cond"] == ci] for _, pr in lst])
        op = np.concatenate([pr["unseen_osnr_pred"][pr["unseen_cond"] == ci] for _, pr in lst])
        res["unseen_bias"][cn] = dict(
            bias=[float((op[o == k] - k).mean()) for k in osnr_grid],
            mae=[float(np.abs(op[o == k] - k).mean()) for k in osnr_grid],
            mae_le20=float(np.abs(op[o <= 20] - o[o <= 20]).mean()),
            mae_gt20=float(np.abs(op[o > 20] - o[o > 20]).mean()))
    # SNR saturation per unseen condition (from data) for the discussion
    un = load("unseen_*.npz")
    res["snr_at_30dB"] = {cn: float(un["snr"][(un["cond"] == ci) & (un["osnr"] == 30)].mean())
                          for ci, cn in enumerate(un["cond_names"])}
    sd = load("seen_*.npz")
    res["snr_at_30dB"].update({cn: float(sd["snr"][(sd["cond"] == ci) & (sd["osnr"] == 30)].mean())
                               for ci, cn in enumerate(sd["cond_names"])})
    # per-format accuracy and MAE, proposed model pooled over seeds
    fp = np.concatenate([pr["seen_fmt_pred"] for _, pr in lst])
    f = np.concatenate([pr["seen_fmt"] for _, pr in lst])
    op = np.concatenate([pr["seen_osnr_pred"] for _, pr in lst])
    o = np.concatenate([pr["seen_osnr"] for _, pr in lst])
    res["per_format"] = {n: dict(acc=float((fp[f == k] == k).mean()),
                                 mae=float(np.abs(op[f == k] - o[f == k]).mean()))
                         for k, n in enumerate(sd["formats"])}
    res["first_osnr_100"] = {m: next((int(k) for k, a in zip(osnr_grid, v["acc"])
                                      if all(x >= 0.999 for x in v["acc"][int(k) - 10:])), None)
                             for m, v in res["per_osnr"].items()}
    xai_p = os.path.join(HERE, "runs", "liteopm_both_s0", "xai.json")
    if os.path.exists(xai_p):
        xr = json.load(open(xai_p))
        fr = np.array(xr["deletion_fracs"])
        auc = lambda y: float(np.trapezoid(y, fr) / (fr[-1] - fr[0]))
        res["deletion_auc"] = {
            "mfi_acc": {t: auc(np.array(xr["deletion"]["mfi"][t])[:, 0]) for t in ("gradcam", "random")},
            "osnr_mae": {t: auc(np.array(xr["deletion"]["osnr"][t])[:, 1]) for t in ("gradcam", "random")}}
    json.dump(res, open(os.path.join(HERE, "results.json"), "w"), indent=1)

    # ---------------------------------------------------------- Fig. 4
    d = load("seen_*.npz")
    names = d["formats"]
    _, pr = runs[("liteopm", "both")][0]
    fig, ax = plt.subplots(1, 3, figsize=(7.0, 2.25),
                           gridspec_kw=dict(width_ratios=[1.15, 1.0, 1.0]))
    for m in ORDER:
        if m in res["per_osnr"]:
            ax[0].plot(osnr_grid, np.array(res["per_osnr"][m]["acc"]) * 100, "-o", ms=2.2,
                       lw=1.1, color=COLORS[m], label=NAMES[m].replace(" (proposed)", "").replace(" CNN", ""))
    ax[0].set_xlabel("OSNR (dB)"); ax[0].set_ylabel("MFI accuracy (%)")
    ax[0].set_ylim(top=100.5); ax[0].legend(fontsize=6.0, loc="lower right", handlelength=1.4, borderaxespad=0.2)
    ax[0].set_title("(a) Format accuracy vs OSNR", fontsize=8)
    lowm = pr["seen_osnr"] <= 14
    cm = np.zeros((6, 6))
    for t, p in zip(pr["seen_fmt"][lowm], pr["seen_fmt_pred"][lowm]):
        cm[t, p] += 1
    cmn = cm / cm.sum(1, keepdims=True) * 100
    ax[1].imshow(cmn, cmap="Blues", vmin=0, vmax=100)
    for i in range(6):
        for j in range(6):
            if cm[i, j]:
                ax[1].text(j, i, f"{cmn[i, j]:.0f}", ha="center", va="center", fontsize=6,
                           color="white" if cmn[i, j] > 60 else "#1f2328")
    short = [n.replace("QAM", "Q").replace("PSK", "P") for n in names]
    ax[1].set_xticks(range(6)); ax[1].set_xticklabels(short, fontsize=6.3)
    ax[1].set_yticks(range(6)); ax[1].set_yticklabels(short, fontsize=6.3)
    ax[1].set_xlabel("Predicted"); ax[1].set_ylabel("True")
    ax[1].set_title("(b) Confusion, OSNR 10-14 dB (%)", fontsize=8)
    for s in ("top", "right"):
        ax[1].spines[s].set_visible(True)
    jit = np.random.default_rng(0).uniform(-0.25, 0.25, len(pr["seen_osnr"]))
    ax[2].scatter(pr["seen_osnr"] + jit, pr["seen_osnr_pred"], s=1.2, alpha=0.35,
                  color=COLORS["liteopm"], lw=0)
    ax[2].plot([9, 31], [9, 31], color="#1f2328", lw=0.7, ls="--")
    ax[2].set_xlim(9, 31); ax[2].set_ylim(9, 31)
    ax[2].set_xlabel("True OSNR (dB)"); ax[2].set_ylabel("Estimated OSNR (dB)")
    ax[2].set_title("(c) OSNR estimation", fontsize=8)
    fig.tight_layout(pad=0.3, w_pad=1.2)
    fig.savefig(os.path.join(FIG, "fig4_results.png"), dpi=300)

    # ---------------------------------------------------------- Fig. 6
    xai_p = os.path.join(HERE, "runs", "liteopm_both_s0", "xai.json")
    if os.path.exists(xai_p):
        xr = json.load(open(xai_p))
        fr = np.array(xr["deletion_fracs"]) * 100
        fig, ax = plt.subplots(1, 3, figsize=(7.0, 2.2))
        for tag, ls in (("gradcam", "-"), ("random", "--")):
            ax[0].plot(fr, np.array(xr["deletion"]["mfi"][tag])[:, 0] * 100, ls, marker="o",
                       ms=2.2, lw=1.1, color=COLORS["liteopm"] if tag == "gradcam" else "#7f8c8d",
                       label="Grad-CAM order" if tag == "gradcam" else "Random order")
            ax[1].plot(fr, np.array(xr["deletion"]["osnr"][tag])[:, 1], ls, marker="o",
                       ms=2.2, lw=1.1, color=COLORS["liteopm"] if tag == "gradcam" else "#7f8c8d")
        ax[0].set_xlabel("Pixels removed (%)"); ax[0].set_ylabel("MFI accuracy (%)")
        ax[0].legend(fontsize=6.5); ax[0].set_title("(a) Deletion test, MFI", fontsize=8)
        ax[1].set_xlabel("Pixels removed (%)"); ax[1].set_ylabel("OSNR MAE (dB)")
        ax[1].set_title("(b) Deletion test, OSNR", fontsize=8)
        conds = list(UNSEEN_LABEL)
        w = 0.2
        for k, m in enumerate(ORDER):
            if m not in res["unseen"]:
                continue
            ys = [res["unseen"][m][c]["mae"][0] for c in conds]
            es = [res["unseen"][m][c]["mae"][1] for c in conds]
            ax[2].bar(np.arange(3) + (k - 1.5) * w, ys, w, yerr=es, color=COLORS[m],
                      label=NAMES[m].replace(" (proposed)", "").replace(" CNN", ""), error_kw=dict(lw=0.6, capsize=1.5))
        ax[2].set_xticks(range(3))
        ax[2].set_xticklabels([UNSEEN_LABEL[c].replace(", ", ",\n") for c in conds], fontsize=6.3)
        ax[2].set_ylabel("OSNR MAE (dB)"); ax[2].set_ylim(0, 4.2)
        ax[2].legend(fontsize=5.8, loc="upper left", ncol=2, handlelength=1.0, columnspacing=0.8)
        ax[2].set_title("(c) Unseen link conditions", fontsize=8)
        fig.tight_layout(pad=0.3, w_pad=1.0)
        fig.savefig(os.path.join(FIG, "fig6_faithful_robust.png"), dpi=300)
    print(json.dumps(res["models"], indent=1))
    print(json.dumps(res["ablation"], indent=1))
    print(json.dumps(res["unseen"], indent=1))


if __name__ == "__main__":
    main()
