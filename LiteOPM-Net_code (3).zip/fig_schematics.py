"""Schematic figures: simulated link (Fig. 1) and LiteOPM-Net (Fig. 2)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
                     "font.size": 8})
INK, EDGE = "#1f2328", "#57606a"
TX, FIB, RX, NET, HEAD = "#dbe9f6", "#e3f1df", "#fbe7d3", "#ece4f6", "#f6e1e1"


def box(ax, x, y, w, h, text, fc, fs=7.2):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.06",
                                fc=fc, ec=EDGE, lw=0.8))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, color=INK)


def arrow(ax, x0, y0, x1, y1):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                arrowprops=dict(arrowstyle="-|>", color=EDGE, lw=0.8, mutation_scale=8))


# ------------------------------------------------------------ Fig. 1 link
fig, ax = plt.subplots(figsize=(7.0, 1.9))
ax.set_xlim(0, 14); ax.set_ylim(0, 3.6); ax.axis("off")
w, h = 1.55, 1.0
xs = [0.1, 1.95, 3.8, 5.65]
labels = ["Symbols +\nQPSK pilots\n(1 in 32)", "RRC shaping\n(roll-off 0.1,\n4 Sa/sym)",
          "Laser phase\nnoise\n(Wiener)", "SSMF span\n(SSFM: loss,\nCD, Kerr)"]
fcs = [TX, TX, TX, FIB]
for x, t, c in zip(xs, labels, fcs):
    box(ax, x, 2.2, w, h, t, c)
for a, b in zip(xs[:-1], xs[1:]):
    arrow(ax, a + w, 2.7, b, 2.7)
box(ax, 7.5, 2.2, 1.2, h, "EDFA", FIB)
arrow(ax, 5.65 + w, 2.7, 7.5, 2.7)
ax.annotate("", xy=(5.65, 3.35), xytext=(8.7, 3.35),
            arrowprops=dict(arrowstyle="-|>", color=EDGE, lw=0.8, ls="--",
                            connectionstyle="arc3,rad=0", mutation_scale=8))
ax.text(7.2, 3.47, "x N spans (80 km each)", ha="center", fontsize=7, color=INK)
box(ax, 9.15, 2.2, 1.55, h, "ASE noise\nloading\n(sets OSNR)", RX)
arrow(ax, 8.7, 2.7, 9.15, 2.7)
# receiver row
rx = [(9.15, "CD\ncompensation"), (7.3, "Matched\nRRC filter,\n1 Sa/sym"),
      (5.45, "Pilot-aided\nphase\nrecovery"), (3.6, "64x64\nconstellation\nimage"),
      (1.75, "LiteOPM-Net")]
for i, (x, t) in enumerate(rx):
    box(ax, x, 0.25, 1.55, h, t, NET if i == 4 else RX)
arrow(ax, 9.9, 2.2, 9.9, 1.25)
for (a, _), (b, _) in zip(rx[:-1], rx[1:]):
    arrow(ax, a, 0.75, b + 1.55, 0.75)
ax.text(0.95, 1.0, "Format\n(6 classes)", ha="center", fontsize=7, color=INK)
ax.text(0.95, 0.25, "OSNR\n(dB)", ha="center", fontsize=7, color=INK)
arrow(ax, 1.75, 0.95, 1.45, 1.15); arrow(ax, 1.75, 0.55, 1.45, 0.4)
ax.text(11.0, 2.7, "Transmitter and fibre link", fontsize=7.5, style="italic", va="center")
ax.text(11.0, 0.75, "Coherent receiver DSP\nand monitor", fontsize=7.5, style="italic",
        va="center")
fig.tight_layout(pad=0.1)
fig.savefig("figs/fig1_link.png", dpi=300)

# ------------------------------------------------------------ Fig. 2 model
fig, ax = plt.subplots(figsize=(7.0, 1.75))
ax.set_xlim(0, 14); ax.set_ylim(0, 3.2); ax.axis("off")
blocks = [("Input\n1x64x64", TX), ("Conv 3x3\n16 ch", NET),
          ("DS block\n32 ch, s2\n32x32", NET), ("DS block\n64 ch, s2\n16x16", NET),
          ("DS block\n96 ch\n16x16", NET), ("DS block\n128 ch\n16x16", NET),
          ("Global\navg pool\n128", NET)]
x, bw, step = 0.05, 1.32, 1.6
for i, (t, c) in enumerate(blocks):
    box(ax, x, 1.15, bw, 1.25, t, c, fs=7)
    if i:
        arrow(ax, x - (step - bw), 1.77, x, 1.77)
    x += step
cam_x = 0.05 + 5 * step + bw / 2
ax.text(cam_x, 2.72, "Grad-CAM layer", ha="center", fontsize=6.8, color="#9a3b3b")
ax.annotate("", xy=(cam_x, 2.44), xytext=(cam_x, 2.68),
            arrowprops=dict(arrowstyle="-|>", color="#9a3b3b", lw=0.7, mutation_scale=6))
pool_r = 0.05 + 6 * step + bw
box(ax, 11.9, 2.0, 2.0, 0.9, "MFI head\nFC-6, softmax", HEAD, fs=7)
box(ax, 11.9, 0.65, 2.0, 0.9, "OSNR head\nFC-64, FC-1", HEAD, fs=7)
arrow(ax, pool_r, 1.9, 11.9, 2.45); arrow(ax, pool_r, 1.65, 11.9, 1.1)
ax.text(0.05, 0.3, "DS block = depthwise 3x3 conv, BN, ReLU, pointwise 1x1 conv, BN, ReLU."
        "   Loss = cross-entropy + L1(OSNR).", ha="left", fontsize=6.8, color=INK)
fig.tight_layout(pad=0.1)
fig.savefig("figs/fig2_model.png", dpi=300)
print("ok")
