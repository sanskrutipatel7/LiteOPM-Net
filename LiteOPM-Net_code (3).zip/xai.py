"""
Grad-CAM analysis of the trained multi-task LiteOPM-Net.

1. Grad-CAM maps for the MFI head (predicted-class logit) and the OSNR head
   (evidence for higher OSNR = +output, evidence for lower OSNR = -output)
2. Physics check: share of each map's mass on
     core  - within 1 sigma of an ideal constellation point
     halo  - between 1 and 2.5 sigma (the noise spread)
     gaps  - everywhere else
   sigma is the per-dimension ASE noise std from the measured SNR.
3. Faithfulness (deletion test): remove the top-k% pixels ranked by
   Grad-CAM vs. at random and track accuracy / OSNR error.

    python xai.py --run runs/liteopm_both_s0
"""
import argparse
import json
import os

import numpy as np
import torch
import torch.nn.functional as F

from data import OSNR_MEAN, OSNR_SCALE, load
from fibre_sim import constellation
from models import build

AXIS, IMG = 1.9, 64


def gradcam(model, x, target):
    """target(logits, osnr) -> per-sample scalar. Returns CAMs [B,64,64] in [0,1]."""
    acts, grads = {}, {}
    layer = model.cam_layer
    h1 = layer.register_forward_hook(lambda m, i, o: acts.__setitem__("a", o))
    h2 = layer.register_full_backward_hook(lambda m, gi, go: grads.__setitem__("g", go[0]))
    model.eval()
    x = x.clone().requires_grad_(True)
    logits, osnr = model(x)
    model.zero_grad()
    target(logits, osnr).sum().backward()
    h1.remove(); h2.remove()
    a, g = acts["a"].detach(), grads["g"].detach()
    w = g.mean(dim=(2, 3), keepdim=True)
    cam = F.relu((w * a).sum(1, keepdim=True))
    cam = F.interpolate(cam, size=(IMG, IMG), mode="bilinear", align_corners=False)[:, 0]
    mx = cam.flatten(1).max(1).values.clamp_min(1e-12)
    return (cam / mx[:, None, None]).numpy()


def region_masks(fmt_name, snr_db):
    """Boolean masks (core, halo, gaps) on the 64x64 image grid."""
    snr = 10 ** (snr_db / 10)
    ps = snr / (1 + snr)                       # signal share after receiver AGC
    sigma = np.sqrt((1 - ps) / 2)
    pts = constellation(fmt_name) * np.sqrt(ps)
    centres = -AXIS + (np.arange(IMG) + 0.5) * (2 * AXIS / IMG)
    re = centres[None, :].repeat(IMG, 0)
    im = centres[::-1][:, None].repeat(IMG, 1)  # row 0 = top = +imag
    z = re + 1j * im
    dist = np.min(np.abs(z[..., None] - pts[None, None, :]), axis=-1)
    core = dist <= sigma
    halo = (dist > sigma) & (dist <= 2.5 * sigma)
    return core, halo, ~(core | halo)


def mass_shares(cam, masks):
    tot = cam.sum() + 1e-12
    return [float(cam[m].sum() / tot) for m in masks]


@torch.no_grad()
def eval_batch(model, x, fmt, osnr):
    model.eval()
    logits, o = model(x)
    acc = float((logits.argmax(1).numpy() == fmt).mean())
    mae = float(np.abs(o.numpy() * OSNR_SCALE + OSNR_MEAN - osnr).mean())
    return acc, mae


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="runs/liteopm_both_s0")
    ap.add_argument("--n", type=int, default=600, help="test images used")
    a = ap.parse_args()
    torch.set_num_threads(1)

    info = json.load(open(os.path.join(a.run, "info.json")))
    model = build(info["model"], info["task"])
    model.load_state_dict(torch.load(os.path.join(a.run, "best.pt")))
    p = np.load(os.path.join(a.run, "preds.npz"))
    d = load("seen_*.npz")
    rng = np.random.default_rng(0)
    idx = np.sort(rng.choice(p["seen_idx"], size=min(a.n, len(p["seen_idx"])), replace=False))
    x = torch.from_numpy(d["x"][idx].astype(np.float32) / 255.0).unsqueeze(1)
    fmt, osnr, snr = d["fmt"][idx], d["osnr"][idx], d["snr"][idx]
    names = d["formats"]

    with torch.no_grad():
        pred = model(x)[0].argmax(1)
    cam_mfi = gradcam(model, x, lambda l, o: l.gather(1, pred[:, None])[:, 0])
    cam_hi = gradcam(model, x, lambda l, o: o)
    cam_lo = gradcam(model, x, lambda l, o: -o)

    # ---- physics check: where does each map put its mass?
    rows = []
    for i in range(len(idx)):
        m = region_masks(names[fmt[i]], float(snr[i]))
        area = [float(mm.mean()) for mm in m]
        rows.append(dict(fmt=int(fmt[i]), osnr=float(osnr[i]), area=area,
                         mfi=mass_shares(cam_mfi[i], m), hi=mass_shares(cam_hi[i], m),
                         lo=mass_shares(cam_lo[i], m)))

    def summarise(sel):
        r = [rows[i] for i in sel]
        return {k: np.mean([q[k] for q in r], axis=0).round(3).tolist()
                for k in ("area", "mfi", "hi", "lo")}

    phys = {"all": summarise(range(len(rows))),
            "osnr_ge_18": summarise([i for i, q in enumerate(rows) if q["osnr"] >= 18]),
            "osnr_le_14": summarise([i for i, q in enumerate(rows) if q["osnr"] <= 14])}

    # ---- deletion test
    fracs = np.arange(0, 0.55, 0.05)
    flat = x.view(len(x), -1)
    del_res = {}
    for name, cam in [("mfi", cam_mfi), ("osnr", np.maximum(cam_hi, cam_lo))]:
        order = np.argsort(-cam.reshape(len(x), -1), axis=1)
        rnd = np.argsort(rng.random(order.shape), axis=1)
        curves = {"gradcam": [], "random": []}
        for f in fracs:
            k = int(round(f * IMG * IMG))
            for tag, ordr in (("gradcam", order), ("random", rnd)):
                xx = flat.clone()
                if k:
                    rows_i = np.repeat(np.arange(len(x)), k)
                    xx[rows_i, ordr[:, :k].ravel()] = 0.0
                curves[tag].append(eval_batch(model, xx.view_as(x), fmt, osnr))
        del_res[name] = {t: np.array(v).tolist() for t, v in curves.items()}

    out = dict(physics=phys, deletion_fracs=fracs.round(2).tolist(), deletion=del_res,
               n_images=len(idx))
    json.dump(out, open(os.path.join(a.run, "xai.json"), "w"), indent=1)
    np.savez_compressed(os.path.join(a.run, "cams.npz"), idx=idx, cam_mfi=cam_mfi,
                        cam_hi=cam_hi, cam_lo=cam_lo, fmt=fmt, osnr=osnr, snr=snr)
    print(json.dumps(phys, indent=1))
    for name in del_res:
        print(name, "gradcam:", np.round(del_res[name]["gradcam"], 3)[:, 0 if name == "mfi" else 1])
        print(name, "random: ", np.round(del_res[name]["random"], 3)[:, 0 if name == "mfi" else 1])


if __name__ == "__main__":
    main()
