"""
Pilot dataset generator for joint Modulation Format Identification (MFI)
and OSNR monitoring in a coherent optical link.

Scope of this pilot (deliberately simple, to confirm the pipeline works):
  - One link: 80 km SSMF, 32 GBaud, dual-polarisation (one pol. imaged)
  - Six formats: QPSK, 8PSK, 8QAM (star), 16QAM, 32QAM (cross), 64QAM
  - OSNR 10-30 dB in 1 dB steps
  - Symbol-level model of the signal after receiver DSP:
        ASE noise (set from OSNR)
      + laser phase noise (Wiener, 100 kHz combined linewidth),
        followed by a block-average carrier phase estimate -> residual phase
      + self-phase-modulation (Kerr) phase rotation, power dependent,
        with ideal CD compensation (CD is fully removed by DSP at 80 km)
  - Output: 64x64 constellation density images (uint8), labels, metadata

The full-paper version should replace this with a split-step Fourier fibre
model (e.g. OptiCommPy) and vary fibre length / launch power.

Usage:
    python simulate_pilot.py --out pilot_dataset.npz --per_class 30
"""

import argparse
import json
import numpy as np

# ---------------------------------------------------------------- constants
BAUD = 32e9             # symbol rate (Hz)
B_REF = 12.5e9          # OSNR reference bandwidth, 0.1 nm at 1550 nm (Hz)
N_POL = 2               # dual polarisation
LINEWIDTH = 100e3       # combined Tx + LO laser linewidth (Hz)
CPE_BLOCK = 64          # symbols per carrier-phase-estimation block
FIBRE_KM = 80.0
GAMMA = 1.3             # nonlinear coefficient (1/W/km)
ALPHA_DB = 0.2          # attenuation (dB/km)
LAUNCH_DBM = 2.0        # launch power per channel (dBm)
N_SYM = 4096            # symbols per image
IMG = 64                # image size (pixels)
AXIS = 1.9              # constellation plot range (+/-), unit-power scale

FORMATS = ["QPSK", "8PSK", "8QAM", "16QAM", "32QAM", "64QAM"]
OSNR_DB = np.arange(10, 31, 1)


# ------------------------------------------------------------ constellations
def square_qam(m):
    k = int(np.sqrt(m))
    lv = np.arange(-(k - 1), k, 2)
    i, q = np.meshgrid(lv, lv)
    return (i + 1j * q).ravel()


def cross_32qam():
    lv = np.arange(-5, 6, 2)
    i, q = np.meshgrid(lv, lv)
    pts = (i + 1j * q).ravel()
    keep = ~((np.abs(pts.real) == 5) & (np.abs(pts.imag) == 5))
    return pts[keep]                                    # 36 - 4 corners = 32


def star_8qam():
    r1, r2 = 1.0, 1.0 + np.sqrt(3)                      # standard ring ratio
    inner = r1 * np.exp(1j * np.pi / 2 * np.arange(4))
    outer = r2 * np.exp(1j * (np.pi / 4 + np.pi / 2 * np.arange(4)))
    return np.concatenate([inner, outer])


def constellation(name):
    if name == "QPSK":
        c = np.exp(1j * (np.pi / 4 + np.pi / 2 * np.arange(4)))
    elif name == "8PSK":
        c = np.exp(1j * np.pi / 4 * np.arange(8))
    elif name == "8QAM":
        c = star_8qam()
    elif name == "16QAM":
        c = square_qam(16)
    elif name == "32QAM":
        c = cross_32qam()
    elif name == "64QAM":
        c = square_qam(64)
    else:
        raise ValueError(name)
    return c / np.sqrt(np.mean(np.abs(c) ** 2))          # unit average power


# -------------------------------------------------------------- impairments
def osnr_to_snr_db(osnr_db):
    """SNR per symbol from OSNR (0.1 nm ref), dual-pol signal."""
    return osnr_db + 10 * np.log10(2 * B_REF / (N_POL * BAUD))


def residual_phase_noise(n, rng):
    """Wiener laser phase noise, then block-average CPE -> residual error."""
    var = 2 * np.pi * LINEWIDTH / BAUD
    phase = np.cumsum(rng.normal(0, np.sqrt(var), n))
    n_blk = n // CPE_BLOCK
    est = phase[: n_blk * CPE_BLOCK].reshape(n_blk, CPE_BLOCK).mean(axis=1)
    est = np.repeat(est, CPE_BLOCK)
    est = np.concatenate([est, np.full(n - est.size, est[-1])])
    return phase - est


def spm_phase(x):
    """Kerr self-phase rotation, proportional to instantaneous power."""
    p_w = 1e-3 * 10 ** (LAUNCH_DBM / 10)
    alpha = ALPHA_DB / (10 * np.log10(np.e))            # 1/km
    l_eff = (1 - np.exp(-alpha * FIBRE_KM)) / alpha     # km
    phi_peak_mean = GAMMA * p_w * l_eff                 # mean nonlinear phase
    # DSP removes the average rotation; the power-dependent part remains
    return phi_peak_mean * (np.abs(x) ** 2 - np.mean(np.abs(x) ** 2))


def simulate(fmt, osnr_db, rng):
    c = constellation(fmt)
    x = c[rng.integers(0, len(c), N_SYM)]
    x = x * np.exp(1j * spm_phase(x))
    x = x * np.exp(1j * residual_phase_noise(N_SYM, rng))
    snr_lin = 10 ** (osnr_to_snr_db(osnr_db) / 10)
    sigma = np.sqrt(1 / (2 * snr_lin))
    y = x + sigma * (rng.normal(size=N_SYM) + 1j * rng.normal(size=N_SYM))
    return y / np.sqrt(np.mean(np.abs(y) ** 2))           # receiver AGC


def to_image(y):
    h, _, _ = np.histogram2d(
        y.real, y.imag, bins=IMG, range=[[-AXIS, AXIS], [-AXIS, AXIS]]
    )
    h = np.log1p(h)                                       # compress peaks
    h = h / h.max() if h.max() > 0 else h
    return (h.T[::-1] * 255).astype(np.uint8)             # imag axis upward


# --------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="pilot_dataset.npz")
    ap.add_argument("--per_class", type=int, default=30,
                    help="images per (format, OSNR) pair")
    ap.add_argument("--seed", type=int, default=2026)
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    imgs, fmt_lbl, osnr_lbl = [], [], []
    for fi, fmt in enumerate(FORMATS):
        for osnr in OSNR_DB:
            for _ in range(args.per_class):
                imgs.append(to_image(simulate(fmt, osnr, rng)))
                fmt_lbl.append(fi)
                osnr_lbl.append(osnr)

    meta = dict(
        formats=FORMATS, osnr_db=OSNR_DB.tolist(), baud=BAUD,
        fibre_km=FIBRE_KM, launch_dbm=LAUNCH_DBM, linewidth_hz=LINEWIDTH,
        cpe_block=CPE_BLOCK, n_sym_per_image=N_SYM, image_size=IMG,
        axis_range=AXIS, per_class=args.per_class, seed=args.seed,
        model="symbol-level post-DSP: ASE + residual laser phase noise + SPM",
    )
    np.savez_compressed(
        args.out, images=np.stack(imgs), fmt=np.array(fmt_lbl, np.int8),
        osnr=np.array(osnr_lbl, np.float32), meta=json.dumps(meta),
    )
    print(f"Saved {len(imgs)} images to {args.out}")


if __name__ == "__main__":
    main()
