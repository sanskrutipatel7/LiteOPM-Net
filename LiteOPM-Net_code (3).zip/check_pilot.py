"""
Sanity checks on the pilot dataset:
  1. Preview grid: each format at OSNR 10, 15, 20, 25, 30 dB
  2. Quick learnability test with simple sklearn models
     (not the paper model - just proof that the labels are recoverable)
"""
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import accuracy_score, mean_absolute_error, confusion_matrix

import sys
src = sys.argv[1] if len(sys.argv) > 1 else "pilot_ssfm.npz"
d = np.load(src)
X, fmt, osnr = d["images"], d["fmt"], d["osnr"]
meta = json.loads(str(d["meta"]))
names = meta["formats"]

# ---------------- preview grid
cols = [10, 15, 20, 25, 30]
fig, ax = plt.subplots(len(names), len(cols), figsize=(len(cols) * 1.7, len(names) * 1.7))
for r, n in enumerate(names):
    for c, o in enumerate(cols):
        idx = np.where((fmt == r) & (osnr == o))[0][0]
        ax[r, c].imshow(X[idx], cmap="magma")
        ax[r, c].set_xticks([]); ax[r, c].set_yticks([])
        if r == 0: ax[r, c].set_title(f"{o} dB", fontsize=9)
        if c == 0: ax[r, c].set_ylabel(n, fontsize=9)
fig.suptitle(f"Constellations after {meta['fibre_km']:.0f} km SSMF "
             f"(split-step), 32 GBaud: format vs OSNR", fontsize=10)
fig.tight_layout()
fig.savefig(src.replace(".npz", "_preview.png"), dpi=150)

if "snr_eff" in d:
    print("Effective SNR from EVM (mean over formats) vs OSNR:")
    for o in [10, 15, 20, 25, 30]:
        print(f"   OSNR {o} dB -> SNR {d['snr_eff'][osnr == o].mean():.2f} dB "
              f"(ASE-only theory {o + 10*np.log10(12.5/32):.2f} dB)")

# ---------------- learnability check (downsample to 32x32 for speed)
Xs = X.reshape(-1, 32, 2, 32, 2).mean(axis=(2, 4)).reshape(len(X), -1) / 255.0
Xtr, Xte, ftr, fte, otr, ote = train_test_split(
    Xs, fmt, osnr, test_size=0.25, random_state=0, stratify=fmt)

clf = LogisticRegression(max_iter=2000, C=1.0).fit(Xtr, ftr)
fpred = clf.predict(Xte)
acc = accuracy_score(fte, fpred)

# per-format OSNR regressors (format assumed known, as a simple baseline)
mae_all, mae_by_fmt = [], {}
for k, n in enumerate(names):
    tr, te = ftr == k, fte == k
    reg = Ridge(alpha=1.0).fit(Xtr[tr], otr[tr])
    p = np.clip(reg.predict(Xte[te]), 10, 30)
    mae_by_fmt[n] = float(mean_absolute_error(ote[te], p))
    mae_all.append(np.abs(ote[te] - p))
mae = float(np.concatenate(mae_all).mean())

# accuracy at low OSNR
low = ote <= 14
acc_low = accuracy_score(fte[low], fpred[low])

print(f"Images: {len(X)}  shape: {X.shape[1:]}  formats: {names}")
print(f"MFI accuracy (all OSNR):     {acc*100:.1f}%")
print(f"MFI accuracy (OSNR <= 14 dB): {acc_low*100:.1f}%")
print(f"OSNR MAE (ridge, format known): {mae:.2f} dB")
print("OSNR MAE by format:", {k: round(v, 2) for k, v in mae_by_fmt.items()})
print("Confusion matrix (rows=true):")
print(confusion_matrix(fte, fpred))
