"""Writes LiteOPM-Net_rerun_colab.ipynb (a Google Colab notebook)."""
import json

cells = []


def md(text):
    cells.append({"cell_type": "markdown", "metadata": {}, "source": text.strip("\n")})


def code(text):
    cells.append({"cell_type": "code", "metadata": {}, "execution_count": None,
                  "outputs": [], "source": text.strip("\n")})


md("""
# Re-run the LiteOPM-Net experiments (IJMOT paper)

This notebook repeats every experiment in the paper and checks that your numbers match the manuscript.

**Before you start**
1. Click **Runtime → Change runtime type → T4 GPU → Save**.
2. Have these two files ready on your computer:
   - `LiteOPM-Net_code.zip` (required)
   - `LiteOPM-Net_data_and_results.zip` (needed only if you skip the data generation step)
3. Click **Runtime → Run all**. When asked, upload the zip files.

**How long it takes (free T4 GPU)**
- Quick check, using the dataset I generated: about 45–75 minutes
- Full re-run, also regenerating the dataset: add about 1 hour

Keep this browser tab open while it runs. If Colab disconnects, just run all cells again: finished training runs are skipped, so it picks up where it stopped (if you set `SAVE_TO_DRIVE = True`).
""")

md("## 1. Settings")
code("""
# True  = also regenerate the 11,340-image dataset from the simulator (adds ~1 hour)
# False = use the dataset from LiteOPM-Net_data_and_results.zip (faster)
REGENERATE_DATA = False

# True = keep all work in Google Drive (folder MyDrive/LiteOPM-Net), so progress
#        survives a Colab disconnect. You will be asked to allow Drive access.
SAVE_TO_DRIVE = False
""")

md("## 2. Check the GPU and set up the folder")
code("""
import os, glob, shutil, subprocess, torch
print("GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else
      "NONE - training will be slow. Use Runtime > Change runtime type > T4 GPU")

if SAVE_TO_DRIVE:
    from google.colab import drive
    drive.mount("/content/drive")
    WORK = "/content/drive/MyDrive/LiteOPM-Net"
else:
    WORK = "/content/LiteOPM-Net"
os.makedirs(WORK, exist_ok=True)
os.chdir(WORK)
print("Working folder:", WORK)
""")

md("## 3. Upload the zip files")
code("""
from google.colab import files

need = ["LiteOPM-Net_code.zip"] + ([] if REGENERATE_DATA else ["LiteOPM-Net_data_and_results.zip"])
missing = [f for f in need if not os.path.exists(f)]
if missing:
    print("Please upload:", ", ".join(missing))
    up = files.upload()
    for name in up:                       # Colab may rename repeats, e.g. "x (1).zip"
        for want in need:
            if name != want and name.startswith(want[:-4]):
                os.replace(name, want)
missing = [f for f in need if not os.path.exists(f)]
assert not missing, f"Still missing: {missing}"
print("Files ready:", need)
""")

md("## 4. Unpack")
code("""
!unzip -oq LiteOPM-Net_code.zip
# keep the numbers from the manuscript for the comparison at the end
if not os.path.exists("reference_results.json"):
    shutil.copy("results.json", "reference_results.json")
if not os.path.exists("reference_validation.json"):
    shutil.copy("validation.json", "reference_validation.json")

if REGENERATE_DATA:
    os.makedirs("data", exist_ok=True)
else:
    !unzip -oq LiteOPM-Net_data_and_results.zip "data/*"
print("Data files:", sorted(os.path.basename(f) for f in glob.glob("data/*.npz")))
""")

md("""
## 5. Check the fibre simulator (about 3 minutes)
Compares the simulator with known theory. The numbers should match `validation.json` from the paper.
""")
code("""
!python validate_sim.py
""")

md("""
## 6. Generate the dataset (only if `REGENERATE_DATA = True`, about 1 hour)
Already-finished link conditions are skipped.
""")
code("""
if REGENERATE_DATA:
    !bash run_full_dataset.sh
else:
    print("Skipped: using the dataset from the zip file.")
""")

md("""
## 7. Train all models (about 30–60 minutes on a T4 GPU)
18 runs: LiteOPM-Net (joint, MFI-only, OSNR-only) and three baselines, each with 3 seeds.
Finished runs are skipped, so you can re-run this cell after a disconnect.
""")
code("""
import json, time
jobs = []
for s in (0, 1, 2):
    for task in ("both", "mfi", "osnr"):
        jobs.append(("liteopm", task, s, "2e-3"))
for s in (0, 1, 2):
    for m in ("mobilenetv2", "alexstyle", "resnet18"):
        jobs.append((m, "both", s, "1e-3"))

t_all = time.time()
for k, (m, task, s, lr) in enumerate(jobs, 1):
    run = f"runs/{m}_{task}_s{s}"
    if os.path.exists(f"{run}/info.json"):
        print(f"[{k:2d}/{len(jobs)}] skip {run} (done)")
        continue
    os.makedirs(run, exist_ok=True)
    t = time.time()
    with open(f"{run}/train.log", "w") as log:
        r = subprocess.run(["python", "train.py", "--model", m, "--task", task, "--seed", str(s),
                            "--lr", lr, "--threads", "2"], stdout=log, stderr=subprocess.STDOUT)
    if r.returncode != 0:
        print(open(f"{run}/train.log").read()[-2000:])
        raise RuntimeError(f"{run} failed")
    last = [l for l in open(f"{run}/train.log") if l.startswith("ep 30")]
    print(f"[{k:2d}/{len(jobs)}] done {run} in {time.time()-t:.0f}s  {last[0].strip() if last else ''}")
print(f"All training finished in {(time.time()-t_all)/60:.0f} min")
""")

md("## 8. Grad-CAM analysis, tables and figures (about 3 minutes)")
code("""
!python xai.py --run runs/liteopm_both_s0 --n 600 > xai_log.txt && echo "Grad-CAM done"
!python analyze.py > analyze_log.txt && echo "Tables done"
!python fig_schematics.py > /dev/null && python fig_gradcam.py > /dev/null && echo "Figures done"
""")

md("""
## 9. Compare with the manuscript
Training on a different machine (GPU instead of CPU) changes rounding, so numbers will not be
identical. They should agree within the run-to-run spread already reported in the paper.
CPU latency depends on the computer and is shown only for information.
""")
code("""
ref = json.load(open("reference_results.json"))
new = json.load(open("results.json"))
NAMES = {"liteopm": "LiteOPM-Net", "alexstyle": "AlexNet-style", "mobilenetv2": "MobileNetV2",
         "resnet18": "ResNet-18"}
rows, problems = [], []

def check(label, r, n, scale, unit, floor):
    diff = abs(n[0] - r[0]) * scale
    tol = max(floor, 2 * max(r[1], n[1]) * scale)       # 2 x seed std, with a minimum
    ok = diff <= tol
    rows.append((label, f"{r[0]*scale:.2f} ± {r[1]*scale:.2f}", f"{n[0]*scale:.2f} ± {n[1]*scale:.2f}",
                 f"{diff:.2f} {unit}", "OK" if ok else "CHECK"))
    if not ok:
        problems.append(label)

for m in ("liteopm", "alexstyle", "mobilenetv2", "resnet18"):
    r, n = ref["models"][m], new["models"][m]
    check(f"{NAMES[m]}: MFI accuracy (%)", r["acc"], n["acc"], 100, "pts", 0.5)
    check(f"{NAMES[m]}: OSNR MAE (dB)", r["mae"], n["mae"], 1, "dB", 0.05)
for t in ("mfi", "osnr"):
    key = "acc" if t == "mfi" else "mae"
    check(f"LiteOPM-Net {t.upper()}-only: {'accuracy (%)' if t=='mfi' else 'OSNR MAE (dB)'}",
          ref["ablation"][t][key], new["ablation"][t][key], 100 if t == "mfi" else 1,
          "pts" if t == "mfi" else "dB", 0.5 if t == "mfi" else 0.05)
for c in ("unseen_160km_1dBm", "unseen_560km_3dBm", "unseen_80km_2dBm_1MHz"):
    check(f"LiteOPM-Net unseen {c[7:]}: OSNR MAE (dB)", ref["unseen"]["liteopm"][c]["mae"],
          new["unseen"]["liteopm"][c]["mae"], 1, "dB", 0.1)

w = max(len(r[0]) for r in rows)
print(f"{'Metric':{w}s}  {'Paper':>14s}  {'Your re-run':>14s}  {'Diff':>9s}  Result")
for r in rows:
    print(f"{r[0]:{w}s}  {r[1]:>14s}  {r[2]:>14s}  {r[3]:>9s}  {r[4]}")
print()
print("Parameters (must match exactly):",
      all(ref["models"][m]["params"] == new["models"][m]["params"] for m in NAMES))
print("CPU latency, ms/img (hardware dependent):",
      {NAMES[m]: round(new["models"][m]["latency_ms"], 2) for m in NAMES})
print()
if problems:
    print("Some metrics differ by more than the expected spread:", problems)
    print("Send me results.json and I will look into it.")
else:
    print("RESULT: your re-run matches the manuscript within the expected run-to-run spread.")
""")

md("## 10. Look at the figures")
code("""
from IPython.display import Image, display
for f in ["fig4_results.png", "fig5_gradcam.png", "fig6_faithful_robust.png"]:
    print(f); display(Image(f"figs/{f}", width=900))
""")

md("""
## 11. Download your results
Downloads `my_rerun_results.zip` with your `results.json`, figures and training logs.
""")
code("""
!zip -qr my_rerun_results.zip results.json validation.json figs runs/*/info.json runs/*/train.log runs/*/history.json xai_log.txt analyze_log.txt
files.download("my_rerun_results.zip")
""")

nb = {"cells": cells,
      "metadata": {"accelerator": "GPU", "colab": {"provenance": [], "gpuType": "T4"},
                   "kernelspec": {"display_name": "Python 3", "name": "python3"},
                   "language_info": {"name": "python"}},
      "nbformat": 4, "nbformat_minor": 0}
json.dump(nb, open("LiteOPM-Net_rerun_colab.ipynb", "w"), indent=1)
print("wrote LiteOPM-Net_rerun_colab.ipynb with", len(cells), "cells")
