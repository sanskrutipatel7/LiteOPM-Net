"""
Models for joint modulation format identification (MFI) and OSNR estimation.

Every model returns (logits[B, 6], osnr_norm[B]). Single-task variants
return the unused output as zeros so one training loop serves all.

  LiteOPMNet   proposed: lightweight depthwise-separable CNN, shared
               backbone with two heads (task = "both" | "mfi" | "osnr")
  AlexStyleCNN classic 5-conv CNN in the style of early CNN-based optical
               performance monitoring work
  ResNet18MT   ResNet-18 (torchvision) with 1-channel input and two heads
  MobileNetV2MT MobileNetV2 (torchvision) with 1-channel input and two heads
"""
import torch
import torch.nn as nn


class DSBlock(nn.Module):
    """Depthwise 3x3 -> BN -> ReLU -> pointwise 1x1 -> BN -> ReLU."""

    def __init__(self, c_in, c_out, stride):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(c_in, c_in, 3, stride, 1, groups=c_in, bias=False),
            nn.BatchNorm2d(c_in), nn.ReLU(inplace=True),
            nn.Conv2d(c_in, c_out, 1, bias=False),
            nn.BatchNorm2d(c_out), nn.ReLU(inplace=True))

    def forward(self, x):
        return self.net(x)


class TwoHeads(nn.Module):
    def __init__(self, c, n_cls, task):
        super().__init__()
        self.task = task
        self.mfi = nn.Linear(c, n_cls) if task in ("both", "mfi") else None
        self.osnr = (nn.Sequential(nn.Linear(c, 64), nn.ReLU(inplace=True),
                                   nn.Linear(64, 1))
                     if task in ("both", "osnr") else None)
        self.n_cls = n_cls

    def forward(self, h):
        b = h.shape[0]
        logits = self.mfi(h) if self.mfi is not None else h.new_zeros(b, self.n_cls)
        osnr = self.osnr(h).squeeze(1) if self.osnr is not None else h.new_zeros(b)
        return logits, osnr


class LiteOPMNet(nn.Module):
    def __init__(self, n_cls=6, task="both", width=(16, 32, 64, 96, 128)):
        super().__init__()
        w = width
        self.stem = nn.Sequential(nn.Conv2d(1, w[0], 3, 1, 1, bias=False),
                                  nn.BatchNorm2d(w[0]), nn.ReLU(inplace=True))
        self.features = nn.Sequential(
            DSBlock(w[0], w[1], 2),     # 64 -> 32
            DSBlock(w[1], w[2], 2),     # 32 -> 16
            DSBlock(w[2], w[3], 1),     # 16
            DSBlock(w[3], w[4], 1))     # 16  (Grad-CAM layer, 16x16 maps)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.heads = TwoHeads(w[4], n_cls, task)

    @property
    def cam_layer(self):
        return self.features[-1]

    def forward(self, x):
        h = self.pool(self.features(self.stem(x))).flatten(1)
        return self.heads(h)


class AlexStyleCNN(nn.Module):
    def __init__(self, n_cls=6, task="both"):
        super().__init__()
        def blk(i, o, pool):
            layers = [nn.Conv2d(i, o, 3, 1, 1), nn.BatchNorm2d(o), nn.ReLU(inplace=True)]
            if pool:
                layers.append(nn.MaxPool2d(2))
            return layers
        self.features = nn.Sequential(*blk(1, 32, True), *blk(32, 64, True),
                                      *blk(64, 128, False), *blk(128, 128, False),
                                      *blk(128, 128, True))          # 8x8
        self.fc = nn.Sequential(nn.Flatten(), nn.Linear(128 * 8 * 8, 256),
                                nn.ReLU(inplace=True), nn.Dropout(0.3))
        self.heads = TwoHeads(256, n_cls, task)

    @property
    def cam_layer(self):
        return self.features[-2]

    def forward(self, x):
        return self.heads(self.fc(self.features(x)))


class ResNet18MT(nn.Module):
    def __init__(self, n_cls=6, task="both"):
        super().__init__()
        from torchvision.models import resnet18
        m = resnet18(weights=None)
        m.conv1 = nn.Conv2d(1, 64, 7, 2, 3, bias=False)
        m.fc = nn.Identity()
        self.body = m
        self.heads = TwoHeads(512, n_cls, task)

    @property
    def cam_layer(self):
        return self.body.layer4

    def forward(self, x):
        return self.heads(self.body(x))


class MobileNetV2MT(nn.Module):
    def __init__(self, n_cls=6, task="both"):
        super().__init__()
        from torchvision.models import mobilenet_v2
        m = mobilenet_v2(weights=None)
        m.features[0][0] = nn.Conv2d(1, 32, 3, 2, 1, bias=False)
        m.classifier = nn.Identity()
        self.body = m
        self.heads = TwoHeads(1280, n_cls, task)

    @property
    def cam_layer(self):
        return self.body.features[-1]

    def forward(self, x):
        return self.heads(self.body(x))


MODELS = {"liteopm": LiteOPMNet, "alexstyle": AlexStyleCNN,
          "resnet18": ResNet18MT, "mobilenetv2": MobileNetV2MT}


def build(name, task="both"):
    return MODELS[name](task=task)


def count_params(m):
    return sum(p.numel() for p in m.parameters())


def count_macs(m, shape=(1, 1, 64, 64)):
    """Multiply-accumulates of conv and linear layers for one input."""
    macs = []

    def conv_hook(mod, inp, out):
        k = mod.kernel_size[0] * mod.kernel_size[1] * mod.in_channels // mod.groups
        macs.append(out.numel() * k)

    def lin_hook(mod, inp, out):
        macs.append(mod.in_features * mod.out_features)

    hs = []
    for mod in m.modules():
        if isinstance(mod, nn.Conv2d):
            hs.append(mod.register_forward_hook(conv_hook))
        elif isinstance(mod, nn.Linear):
            hs.append(mod.register_forward_hook(lin_hook))
    m.eval()
    with torch.no_grad():
        m(torch.zeros(shape))
    for h in hs:
        h.remove()
    return int(sum(macs))
