"""Fig. 5: Grad-CAM examples for both heads + Fig. 3: example constellations."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from data import load

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
                     "font.size": 8})
d = load("seen_*.npz")
names = d["formats"]

# ------------------------------------------------------------ Fig. 3
c = d["cond_names"].index("seen_400km_2dBm")
osnrs = [12, 20, 30]
fig, ax = plt.subplots(len(osnrs), len(names), figsize=(7.0, 3.65))
for r, o in enumerate(osnrs):
    for k, n in enumerate(names):
        i = np.flatnonzero((d["fmt"] == k) & (d["osnr"] == o) & (d["cond"] == c))[0]
        a = ax[r, k]
        a.imshow(d["x"][i], cmap="magma"); a.set_xticks([]); a.set_yticks([])
        if r == 0:
            a.set_title(n, fontsize=7.5)
        if k == 0:
            a.set_ylabel(f"OSNR {o} dB", fontsize=7.5)
fig.tight_layout(pad=0.2, h_pad=0.25, w_pad=0.15)
fig.savefig("figs/fig3_constellations.png", dpi=300)

# ------------------------------------------------------------ Fig. 5
c = np.load("runs/liteopm_both_s0/cams.npz")
pick = []
for fname, o_lo, o_hi in [("8QAM", 16, 22), ("16QAM", 18, 24), ("64QAM", 22, 28)]:
    fi = names.index(fname)
    cand = np.flatnonzero((c["fmt"] == fi) & (c["osnr"] >= o_lo) & (c["osnr"] <= o_hi))
    pick.append(cand[len(cand) // 2])
cols = ["Input", "MFI head", "OSNR head:\nraises estimate", "OSNR head:\nlowers estimate"]
fig, ax = plt.subplots(3, 4, figsize=(3.45, 2.75))
for r, j in enumerate(pick):
    img = d["x"][c["idx"][j]] / 255.0
    maps = [None, c["cam_mfi"][j], c["cam_hi"][j], c["cam_lo"][j]]
    for k in range(4):
        a = ax[r, k]
        a.imshow(img, cmap="gray_r" if k else "magma", alpha=1.0 if k == 0 else 0.55)
        if k:
            a.imshow(maps[k], cmap="jet", alpha=0.5, vmin=0, vmax=1)
        a.set_xticks([]); a.set_yticks([])
        if r == 0:
            a.set_title(cols[k], fontsize=6.3)
        if k == 0:
            a.set_ylabel(f"{names[c['fmt'][j]]}\n{c['osnr'][j]:.0f} dB", fontsize=6.5)
fig.tight_layout(pad=0.15, h_pad=0.2, w_pad=0.15)
fig.savefig("figs/fig5_gradcam.png", dpi=300)
print("ok", [int(c["osnr"][j]) for j in pick])
